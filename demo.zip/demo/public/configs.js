// var __DomainName='http://10.10.30.170:8182/xdm-web';  // SST
var __DomainName="http://8.m.sit.tuniu.org/xdm"; //SIT
// var __DomainName="https://api.5jyq.com/tnp"; //product
window["SMALL_BLACK_CONFIG"]={
    "_DomainName":__DomainName,
    "_DEBUG":false,  //打开console info
    "_PRODUCT":'DEV' ////DEV or PRD   //开发环境或是生产环境
}

