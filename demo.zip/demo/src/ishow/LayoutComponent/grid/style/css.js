'use strict';

require('../../style/index.css');

require('./index.css');