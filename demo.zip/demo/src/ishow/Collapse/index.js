import Collapse from './Collapse.js';
import CollapseItem from './CollapseItem.js';

Collapse.Item = CollapseItem;

export default Collapse;
