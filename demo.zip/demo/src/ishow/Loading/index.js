import Loading from './Loading.js';

export default Loading;
