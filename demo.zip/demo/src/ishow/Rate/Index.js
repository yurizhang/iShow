import Rate from './Rate.js';

export default Rate;
