import React, { Component } from 'react';
import Menu from '../../ishow/Menu/index.js';
import ParamTable from './paramTable';
import ViewCode from './viewCode';
import './App.css';

//多级菜单页面
class App extends Component {
    constructor(props){
        super(props);
        this.state = {
            //..
        }
    }

    render(){
        return (
            <div>

            </div>
        )
    }
}

export default App