import Icon from './Icon.js';
export default Icon;