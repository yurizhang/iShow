'use strict';

require('./v2-compatible-reset.less');