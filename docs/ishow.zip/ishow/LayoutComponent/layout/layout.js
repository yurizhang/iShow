

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _defineProperty2 = require('babel-runtime/helpers/defineProperty');

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _toConsumableArray2 = require('babel-runtime/helpers/toConsumableArray');

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _react = require('react');

var React = _interopRequireWildcard(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _classnames = require('classnames');

var _classnames2 = _interopRequireDefault(_classnames);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    }if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0; i < p.length; i++) {
        if (e.indexOf(p[i]) < 0) t[p[i]] = s[p[i]];
    }return t;
};

function generator(props) {
    return function (BasicComponent) {
        return function (_React$Component) {
            (0, _inherits3['default'])(Adapter, _React$Component);

            function Adapter() {
                (0, _classCallCheck3['default'])(this, Adapter);
                return (0, _possibleConstructorReturn3['default'])(this, (Adapter.__proto__ || Object.getPrototypeOf(Adapter)).apply(this, arguments));
            }

            (0, _createClass3['default'])(Adapter, [{
                key: 'render',
                value: function render() {
                    var prefixCls = props.prefixCls;

                    return React.createElement(BasicComponent, (0, _extends3['default'])({ prefixCls: prefixCls }, this.props));
                }
            }]);
            return Adapter;
        }(React.Component);
    };
}

var Basic = function (_React$Component2) {
    (0, _inherits3['default'])(Basic, _React$Component2);

    function Basic() {
        (0, _classCallCheck3['default'])(this, Basic);
        return (0, _possibleConstructorReturn3['default'])(this, (Basic.__proto__ || Object.getPrototypeOf(Basic)).apply(this, arguments));
    }

    (0, _createClass3['default'])(Basic, [{
        key: 'render',
        value: function render() {
            var _a = this.props,
                prefixCls = _a.prefixCls,
                className = _a.className,
                children = _a.children,
                others = __rest(_a, ["prefixCls", "className", "children"]);
            var divCls = (0, _classnames2['default'])(className, prefixCls);
            return React.createElement(
                'div',
                (0, _extends3['default'])({ className: divCls }, others),
                children
            );
        }
    }]);
    return Basic;
}(React.Component);

var BasicLayout = function (_React$Component3) {
    (0, _inherits3['default'])(BasicLayout, _React$Component3);

    function BasicLayout() {
        (0, _classCallCheck3['default'])(this, BasicLayout);

        var _this3 = (0, _possibleConstructorReturn3['default'])(this, (BasicLayout.__proto__ || Object.getPrototypeOf(BasicLayout)).apply(this, arguments));

        _this3.state = { siders: [] };
        return _this3;
    }

    (0, _createClass3['default'])(BasicLayout, [{
        key: 'getChildContext',
        value: function getChildContext() {
            var _this4 = this;

            return {
                siderHook: {
                    addSider: function addSider(id) {
                        _this4.setState({
                            siders: [].concat((0, _toConsumableArray3['default'])(_this4.state.siders), [id])
                        });
                    },
                    removeSider: function removeSider(id) {
                        _this4.setState({
                            siders: _this4.state.siders.filter(function (currentId) {
                                return currentId !== id;
                            })
                        });
                    }
                }
            };
        }
    }, {
        key: 'render',
        value: function render() {
            var _a = this.props,
                prefixCls = _a.prefixCls,
                className = _a.className,
                children = _a.children,
                hasSider = _a.hasSider,
                others = __rest(_a, ["prefixCls", "className", "children", "hasSider"]);
            var divCls = (0, _classnames2['default'])(className, prefixCls, (0, _defineProperty3['default'])({}, prefixCls + '-has-sider', hasSider || this.state.siders.length > 0));
            return React.createElement(
                'div',
                (0, _extends3['default'])({ className: divCls }, others),
                children
            );
        }
    }]);
    return BasicLayout;
}(React.Component);

BasicLayout.childContextTypes = {
    siderHook: _propTypes2['default'].object
};
var Layout = generator({
    prefixCls: 'ant-layout'
})(BasicLayout);
var Header = generator({
    prefixCls: 'ant-layout-header'
})(Basic);
var Footer = generator({
    prefixCls: 'ant-layout-footer'
})(Basic);
var Content = generator({
    prefixCls: 'ant-layout-content'
})(Basic);
Layout.Header = Header;
Layout.Footer = Footer;
Layout.Content = Content;
exports['default'] = Layout;
module.exports = exports['default'];