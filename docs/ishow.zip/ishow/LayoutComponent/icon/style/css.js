'use strict';

require('../../style/index.css');