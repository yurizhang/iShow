export default function isFlexSupported(): boolean;
