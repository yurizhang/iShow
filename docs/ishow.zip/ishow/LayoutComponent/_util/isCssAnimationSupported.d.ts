declare function isCssAnimationSupported(): boolean;
export default isCssAnimationSupported;
