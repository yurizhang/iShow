/* @flow */

import Editor from './Editor';

module.exports = {
  Editor,
};
