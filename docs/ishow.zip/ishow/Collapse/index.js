import Collapse from './Collapse.js';
import CollapseItem from './CollapseItem';

Collapse.Item = CollapseItem;

export default Collapse;
