import Progress from './Progress.js';

export default Progress;
