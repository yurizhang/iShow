import Carousel from './Carousel';
import CarouselItem from './CarouselItem';

Carousel.Item = CarouselItem;

export default Carousel;