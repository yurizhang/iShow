import Carousel from './Carousel.js';
import CarouselItem from './CarouselItem';

Carousel.Item = CarouselItem;

export default Carousel;