import Slider from './Slider.js';

export default Slider;
