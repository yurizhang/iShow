import Form from './Form.js';
import FormItem from './FormItem';

Form.Item = FormItem;

export default Form;
