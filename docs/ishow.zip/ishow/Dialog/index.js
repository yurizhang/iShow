import Dialog from './Dialog.js';
export default Dialog;
