
这是一个基于webpack4.x+React+React-router4+iShow UI 的中后台管理方案,<br>
基于React+react-router+iShow UI的中后台方案,开箱即用,零配置,维护一个json即可<br>
1. 里面的代码只是为了演示iShowUI使用，你不能将他用于你的生产环境
2. 以下是ishow UI使用的必须类库：

    "async-validator": "^1.8.2",  
    "css-animation": "^1.4.1",
    "enquire.js": "^2.1.6",
    "omit.js": "^1.0.0",
    "rc-menu": "^6.2.6",
    "rc-tooltip": "^3.7.0",
    "throttle-debounce": "^1.0.1",
    "react-click-outside": "^3.0.1",

3. 运行命令
yarn install 安装

yarn start

yarn build