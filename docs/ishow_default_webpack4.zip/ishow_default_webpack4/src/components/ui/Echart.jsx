import React from "react"
//import BreadcrumbCustom from '../BreadcrumbCustom';

export default class TestSize extends React.Component{

    createIframe(url,minheight='700'){
        document.getElementById("iFrameID").innerHTML="";   

        let iFrame = document.createElement('iframe');
        iFrame.setAttribute('src', url);
        //iFrame.setAttribute('style', 'min-height:1000px');
        iFrame.setAttribute('height', minheight);
        iFrame.setAttribute('width', '100%');
        iFrame.setAttribute('frameborder', '0');
        iFrame.setAttribute('id', 'yuri_iframe');
    
        setTimeout(()=>{document.getElementById("iFrameID").appendChild(iFrame);},0);  
     
  
  }

    //数据平台接口统计
    pointRender2(){
        let url='http://git.hust.cc/echarts-for-react/#/echarts/dynamic?_k=uembgh';
        //url="http://cfbf-cfe.api.tuniu-sst.org/cfe/page/index.html?path=app_server_top_info"; // sst    
     
        let height=document.documentElement.clientHeight-82-60-62-40; 
        this.createIframe(url,height);
        
        //actions.app.updateCrumb(['消费金融','金融数据平台','系统接口统计']);   
        //调用miror里的redurce，更新面包屑
       
        
    }
    componentDidMount(){
       // this.pointRender2()
       console.log(document.getElementById("iFrameID").innerHTML);
     
       this.pointRender2();
    }
    render() {
        return (
            <div>
                <div id="iFrameID">loading</div>
               
                
                <style>{`
                    .testsize-demo {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                `}</style>
                
            </div>
        )
    }

}