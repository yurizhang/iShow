import React from 'react'
import ReactEcharts from 'echarts-for-react'

class Chart5 extends React.Component {
    getOption = () => {
        return {
            xAxis: {
                show: false,
                type: 'category',
                boundaryGap: true,
                data: ['3.15', '3.16', '3.17', '3.18', '3.19', '3.20', '3.21'],
            },
            yAxis: {
                type: 'value',
                show: false
            },
            tooltip: {
                show: true
            },
            series: [{
                data: [2.2, 3.2, 3.5, 3, 2.9, 2.6, 3.1],
                type: 'line',
                areaStyle: {},
                smooth: true,
                color:"#58B7FF"
            }]
        };
    };

    render() {
        return (
            <ReactEcharts
                option={this.getOption()}
                style={{ height: '100px', width: '100%' }}
                className='react_for_echarts' />
        )
    }
}

export default Chart5