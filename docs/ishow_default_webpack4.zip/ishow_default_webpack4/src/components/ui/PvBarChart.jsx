import React from 'react'
import ReactEcharts from 'echarts-for-react'

class Chart4 extends React.Component {
    getOption = () => {
        return {
            xAxis: {
                type: 'category',
                data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            },
            yAxis: {
                type: 'value'
            },
            tooltip: {
                show: true
            },
            series: [{
                data: [220, 200, 250, 150, 170, 180, 190, 180, 170, 210, 230, 220],
                type: 'bar',
                color:"#3fa7dc"
            }]
        };
    };

    render() {
        let {width}=this.props;
        return (
            <ReactEcharts
                option={this.getOption()}
                style={{ height: '300px', width: width }}
                className='react_for_echarts chart4' />
        )
    }
}

export default Chart4