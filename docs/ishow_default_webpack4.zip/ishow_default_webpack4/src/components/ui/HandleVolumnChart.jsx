import React from 'react'
import ReactEcharts from 'echarts-for-react'

class Chart2 extends React.Component {
    getOption = () => {
        return {
            xAxis: {
                type: 'category',
                data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                show: false
            },
            yAxis: {
                type: 'value',
                show: false
            },
            tooltip: {
                show: true
            },
            series: [{
                data: [120, 200, 150, 80, 70, 110, 130],
                type: 'bar',
                color:"#67C23A"
            }]
        };
    };

    render() {
        return (
            <ReactEcharts
                option={this.getOption()}
                style={{ height: '100px', width: '100%', top:'-30px', left:'0px' }}
                className='react_for_echarts' />
        )
    }
}

export default Chart2