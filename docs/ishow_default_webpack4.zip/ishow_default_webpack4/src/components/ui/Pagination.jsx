import React, { Component } from 'react';
import './App.css';
//按需加载
import Button from "../../ishow/Button/index";
import Icon from "../../ishow/Icon/Icon";
import Tag from "../../ishow/Tag/Tag";
import Table from '../../ishow/Table/TableStore';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      //for Table
      columns4: [
        {
          type: 'selection'
        },
        {
          type: 'index'
        },
        {
          label: "日期",
          prop: "date",
          width: 150,
          render: function(data){
            return (
            <span>
              <Icon name="time"/>
              <span style={{marginLeft: '10px'}}>{data.date}</span>
            </span>)
          }
        },
        {
          label: "姓名",
          prop: "name",
          width: 160,
          render: function(data){
            return <Tag>{data.name}</Tag>
          }
        },
        {
          label:"省份",
          prop:"province"
        },
        {
          label:"城市",
          prop:"city"
        },
        {
          label:"地址",
          prop:"address"
        },
        {
          label:"省份",
          prop:"province"
        },
        {
          label: "操作",
          prop: "address",
          width:'150',
          render: function(){
            return (
              <span>
               <Button plain={true} type="info" size="small">编辑</Button>
               <Button type="danger" size="small">删除</Button>
              </span>
            )
          }
        }
      ],
      data4: [{
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }, {
        date: '2018-03-02',
        name: '途牛大前端 -- 张勇',
        province: '江苏',
        city: '玄武区',
        address: '南京市玄武区玄武大道699-32号途牛大厦',
        zip: 200333
       }],
    };
  };
  
  // componentDidMount(){
  //   //console.log(this.props);
  //   this.props.changeBread(['首页','数据','表格']);
  // }


  render() {
    //for Collapse
    return (
      <div className="App">
        <h1>工单发起与查询</h1>
        <h3>常用的表格</h3>
        <div>
        
              <Table
                style={{width: '100%'}}
                columns={this.state.columns4}
                data={this.state.data4}
                border={true}
                stripe={true}
              
                highlightCurrentRow={true}
                onCurrentChange={item=>{console.log(item)}}
                onSelectChange={(selection) => { console.log(selection) }}
                onSelectAll={(selection) => { console.log(selection) }}
              />
        </div>
        <div>
        </div>
      </div>
    );
  }
}

export default App;
