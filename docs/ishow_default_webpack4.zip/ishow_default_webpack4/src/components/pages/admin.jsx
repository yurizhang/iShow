import React from "react"
//import ReactDOM from "react-dom"
import { HashRouter as Router, Link } from "react-router-dom";
//import { Layout, Menu, Icon, Dropdown } from 'antd';
import Row from '../../ishow/LayoutComponent/row/index';
import Col from '../../ishow/LayoutComponent/col/index';
import NiuIcon from '../../ishow/LayoutComponent/icon/index';
import Layout from '../../ishow/LayoutComponent/layout/index';
import NiuMenu from '../../ishow/LayoutComponent/menu/index';
import Tabs from "../../ishow/Tab/index";
import './admim.css';
import { menus as menusList, componentsJSXArray } from '../../constants/menuslist';  // 菜单数据
//import {componentsJSXArray} from '../../constants/menuslist';
// import Crouter from "../../routes/index";  //路由数据
// import notFound from './NotFound.jsx'
import IshowDropdown from '../../ishow/Dropdown/index';//使用ishow中的Dropdown
//import Loadable from 'react-loadable';
// const MyLoadingComponent = ({ isLoading, error }) => {
//   // Handle the loading state
//   if (isLoading) {
//     return <div>Loading...</div>;
//   }
//   // Handle the error state
//   else if (error) {
//     return <div>Sorry, there was a problem loading the page.</div>;
//   }
//   else {
//     return null;
//   }
// };


const { Header, Content, Footer, Sider } = Layout;
//const SubMenu = Menu.SubMenu;

class SiderDemo extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
      openKeys: [],
      rootSubmenuKeys: [],
      Breadcrumb: ['控制台', '控制台'],
      // BreadcrumbindexUrl: '/',
      // tabCurrentTitle: '控制台',
      tabs: [],
      tabIndex: 2,   //总共有多少个标签
      tabCurrent: 1, //当前激活的是那一个标签, 从1开始
      // component:<ReadMeJSX />
    };

  }



  onCollapse = (collapsed) => {
    //console.log(collapsed);
    this.setState({ collapsed });
  }
  onTrigg = () => {
    this.setState({ collapsed: !this.state.collapsed });
  }
  //SubMenu 展开/关闭的回调
  onOpenChange = (openKeys) => {
    //console.log(openKeys);  //所有展开的菜单
    //this.setState({ openKeys });
    // submenu keys of first level
    //const rootSubmenuKeys = ['sub1', 'sub2', 'sub4'];
    //最后一次展开的菜单
    const latestOpenKey = openKeys.find(key => this.state.openKeys.indexOf(key) === -1);  //用户点子菜单标题事件
    //console.log(latestOpenKey);
    this.setState({
      openKeys: latestOpenKey ? [latestOpenKey] : [],  //只把最后一个打开，其它的都关掉
    });
    // if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
    //   this.setState({ openKeys });
    // } else {
    // this.setState({
    //   openKeys: latestOpenKey ? [latestOpenKey] : [],
    // });
    // }
  }
  onClickItem = (obj) => {   //用户点菜单项目事件`  
    //let obj={ item, key, keyPath };
   // const {tabs} = this.state;
    console.log(obj);
    if (obj.keyPath && obj.keyPath.length < 2) {  //如果点击的是不是子菜单项目，就关闭所有子菜单。
      this.setState({
        openKeys: []  //关闭所有打开的子菜单 
      });
    }
    this.queryMenulist(obj);
    //key=   这里的key: '/app/ui', title: 'UI', icon: 'scan', key就是路由`
    //keyPath=如果子菜单里面这个数据会超过2，否则就是1 返回 ["/app/ui/buttons", "/app/ui"]
    //console.log( obj )
    //在这里调用面包应该更优雅
    // this.changeBread([''])  //根据key来得到对应的面包
  }
  
  queryMenulist = (obj) => {
    for (let i = 0; i < menusList.length; i++) {
      if (obj.key === menusList[i].key) {
        this.addTab(obj,menusList[i].index,menusList[i].title);
        return;
      }else {
        if (menusList[i].sub && menusList[i].sub.length){
          let menuSubList = menusList[i].sub;
          for (let j = 0; j < menuSubList.length; j++) {
            if (menuSubList[j].key === obj.key) {
              // this.changeBread(menuSubList[j].breadcrumb);
              this.addTab(obj, menuSubList[j].index,menuSubList[j].title);
              return;
            }
          }
        }
      }
    }
  }
  changeBread = (newBread) => {
    //console.log("修改Breadcrumb");
    //return b;
    //定义这个组件用来修改面包，先转给路由，最后传给icon，button等
    this.setState({
      Breadcrumb: newBread
    });

  }


  addTab(obj, componentIndex,tabTitle) {
    console.log('obj',obj);
    if(componentIndex === 0){
      this.setState({ tabCurrent: 1});
      return;
    }else if(componentIndex === 1){
      this.setState({ tabCurrent:2});
      return;
    }
    const _this = this;
    const { tabs, tabIndex } = this.state;
    let canPush = true; //能否添加新的标签
     
      const _index = tabIndex + 1;
      //检查标签 是否存在如果存在就直接改变Tabs的value
      tabs.forEach(function (item, index) {
        if (item.index === componentIndex) {
          _this.setState({ tabCurrent: Number(item.name.split('_')[1]) });
          canPush = false;
        }
      })
      if (canPush) {
        tabs.push({
          index: componentIndex,
          name: 'Tab_' + _index,   //每个选项卡的名字
          title:tabTitle
          //content: function(){return JSXFile},
        });
        this.setState({
          tabs,
          tabIndex: _index,
          tabCurrent: _index //选中最新的一个
        });
      }
      console.log(tabs);
      this.setState({
        component:componentsJSXArray[componentIndex]
      })
  
  }

  removeTab(tab) {
    const { tabs, tabIndex } = this.state;
    console.log('tabIndex',tab,tab.key.split('$')[1]);
    tabs.splice(tab.key.split('$')[1], 1);
    this.setState({
      tabs,
      tabIndex: tabIndex,
      tabCurrent: tabIndex //选中最新的一个
    });
  }
 
  render() {
    //let menu = this.menu();
    const renderMenuItem =
      ({ key, title, icon, link,index, ...props }) =>
        <NiuMenu.Item
          key={key || link}
          {...props}
        >
          <Link to={link || key}>
            {icon && <NiuIcon type={icon} />}
            <span className="nav-text">{title}</span>
          </Link>
        </NiuMenu.Item>;

    const renderSubMenu =
      ({ key, title, icon, link, sub, ...props }) =>
        <NiuMenu.SubMenu
          key={key || link}
          title={
            <span>
              {icon && <NiuIcon type={icon} />}
              <span className="nav-text">{title}</span>
            </span>
          }
          {...props}
        >
          {sub && sub.map(item => renderMenuItem(item))}
        </NiuMenu.SubMenu>;

    return (
      <Router>
        <Layout style={{ minHeight: '100vh' }} id="components-layout-demo-custom-trigger">
          <Sider
            breakpoint="lg"
            collapsible
            collapsed={this.state.collapsed}
            onCollapse={this.onCollapse}
          >
            <div className="logo">
              <img src="./niu.ico" className="team-logo" alt="niu-icon"/>
              <span className="team-name">{this.state.collapsed ? "":"Elf-Team Design"}</span>
            </div>

            <NiuMenu theme="dark" defaultSelectedKeys={['1']} openKeys={this.state.openKeys} onOpenChange={this.onOpenChange} onClick={this.onClickItem} mode="inline">
              {menusList && menusList.map(item => item.sub && item.sub.length ?
                renderSubMenu(item) : renderMenuItem(item)
              )}
            </NiuMenu>
          </Sider>

          <Layout>
            <Header style={{ background: '#fff'}}>
              <Row type="flex" justify="space-between" align="middle">
                <Col span={24}>
                  <NiuIcon className="trigger" type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'} onClick={this.onTrigg} />
             
                  {/* <Dropdown overlay={menu}>
                    <a className="ant-dropdown-link">
                      Admin <Icon type="down" />
                    </a>
                  </Dropdown> */}
                  <div className="personalModule">
                  <IshowDropdown menu={(<IshowDropdown.Menu>
                    {/* <IshowDropdown.Item>消息</IshowDropdown.Item> */}
                    <IshowDropdown.Item style={{textAlign:'center'}}>
                      <a target="_self" rel="noopener noreferrer" href="https://passport.tuniu.com/login?origin=http://www.tuniu.com/ssoConnect">退出登录</a>
                    </IshowDropdown.Item>
                  </IshowDropdown.Menu>)} trigger="click">
                    <div className="personalModule">
                      <img src="./niu.ico" className="user-avatar" alt="headImg"/>
                      <span className="user-name">Admin</span>
                      <i className="ishow-icon-caret-bottom ishow-icon--right ishow-icon--right-custom"></i>
                    </div>
                  </IshowDropdown>
                  </div>
                </Col>
              </Row>

            </Header>
            <Content style={{ margin: '0 16px' }}>
              {/* <Breadcrumb separator="/" style={{ margin: '16px 0' }}>
                {this.state.Breadcrumb.map((e, i) => (
                  <Breadcrumb.Item key={i}>{e}</Breadcrumb.Item>
                ))}
              </Breadcrumb> */}
              <div className="tabContent" style={{ background: '#fff',margin: '16px 0'}}>
                <Tabs type="card" value={'Tab_' + this.state.tabCurrent} onTabRemove={(tab) => this.removeTab(tab)}>
                  <Tabs.Pane key={0} closable={false} label='控制台' name='Tab_1'>
                   {componentsJSXArray[0]}
                  </Tabs.Pane>
                  <Tabs.Pane key={1} closable={false} label='说明' name='Tab_2'>
                   {componentsJSXArray[1]}
                  </Tabs.Pane>
                  {
                    this.state.tabs.map((item, index) => {
                      return (
                        <Tabs.Pane key={index} closable label={item.title} name={item.name}>
                          {/* {this.renderComponents(item.title)} */}
                          {componentsJSXArray[item.index]}
                          {/* <Route exact path="/app/ui/buttons" component={notFound} />
                        <Crouter/> */}
                        </Tabs.Pane>
                      )
                    })
                  }
                </Tabs>
              </div>
            </Content>
            <Footer style={{ textAlign: 'center' }}>
              TUNIU Design ©2018 Created by <a href="http://wiki.tuniu.org/display/SRDC/2.Tuniu+Backend+System+UI+Standard+2.0" rel="noopener noreferrer" target="_blank">Elf-Team</a>
            </Footer>
          </Layout>
        </Layout>
      </Router>
    );
  }
}


export default SiderDemo
//ReactDOM.render(<SiderDemo />, document.getElementById("root"));

// #components-layout-demo-side .logo {
//   height: 32px;
//   background: rgba(255,255,255,.2);
//   margin: 16px;
// }
