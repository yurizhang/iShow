'use strict';

require('../../style/index.less');