import Pagination from './Pagination.js';

export default Pagination;