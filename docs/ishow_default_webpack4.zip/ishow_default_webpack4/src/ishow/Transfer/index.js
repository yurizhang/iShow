
import Transfer from './Transfer.js';

export default Transfer;