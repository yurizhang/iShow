import Card from './Card.js';

export default Card;
