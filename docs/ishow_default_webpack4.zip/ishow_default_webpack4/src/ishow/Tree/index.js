import Tree from './Tree';

export default Tree;