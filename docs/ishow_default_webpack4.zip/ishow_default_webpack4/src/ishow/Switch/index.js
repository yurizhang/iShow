import Switch from './Switch';
export default Switch;