export default function callMoment(moment: any, ...args: any[]): any;
