export default function getScroll(target: any, top: boolean): number;
