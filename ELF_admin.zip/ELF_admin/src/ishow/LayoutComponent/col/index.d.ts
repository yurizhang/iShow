import { Col, ColProps, ColSize } from '../grid';
import './style/css';
export { ColProps, ColSize };
export default Col;
