import React from "react"
import Loadable from 'react-loadable';
export const menus = [
  { key: '/', title: '控制台', icon: 'home',index:0},
  { key: '/app/introduce', title: '说明', icon: 'home', breadcrumb:['首页','说明'],index:1},
  {
      key: '/app/ui', title: '基础配置', icon: 'appstore-o',
      sub: [
          { key: '/app/ui/buttons', title: '自动分配配置', icon: '',index:2},
          { key: '/app/ui/icons', title: '质量工具配置', icon: '',index:3},
          { key: '/app/ui/colors', title: '人员配置', icon: '',index:4},
          { key: '/app/ui/loading', title: '问题分类配置', icon: '',index:5},
          { key: '/app/ui/message', title: '提醒触发器', icon: '',index:6}
      ],
  },
  {
      key: '/app/nav', title: '投诉单发起', icon: 'scan',
       sub: [
          { key: '/app/nav/tabs', title: '有订单投诉', icon: '',index:7},
          { key: '/app/nav/menu', title: '无订单投诉', icon: '',index:8},
          { key: '/app/nav/breadcrumb', title: '批量变更', icon: '',index:9},
          { key: '/app/nav/dropdown', title: '投诉事宜', icon: '',index:10},
          { key: '/app/nav/step', title: '工单发起与查询', icon: '',index:11},
      ],
  },
  {
      key: '/app/data', title: '投诉单列表', icon: 'table',
      sub: [
          { key: '/app/data/table', title: '投诉提醒工作台', icon: '',  breadcrumb:['数据','表格'],index:12},
          { key: '/app/data/tag', title: '投诉申请与查询', icon: '',  breadcrumb:['数据','标签'],index:13},
          { key: '/app/data/progress', title: '投诉处理', icon: '', breadcrumb:['数据','进度条'],index:14},
          { key: '/app/data/pagination', title: '待回呼列表', icon: '', breadcrumb:['数据','分页'],index:15},
          // { key: '/app/data/test', title: 'test', icon: '', breadcrumb:['数据','test'],index:21},
      ],
  },
  {
      key: '/app/form', title: '预订工作台', icon: 'form',
      sub: [
          { key: '/app/form/formElements', title: '管理员配置', icon: '', breadcrumb:['表单','表单元素'],index:16},
      ],
  },
  {
      key: '/app/chart', title: '赔款审核', icon: 'area-chart',
      sub: [
          { key: '/app/chart/echarts', title: '赔款审核列表', icon: '',  breadcrumb:['图表','echarts'],index:17},
          { key: '/app/chart/piechart', title: '饼图', icon: '', breadcrumb: ['图表', '饼图'] ,index:18},
          { key: '/app/chart/barchart', title: '柱状图', icon: '', breadcrumb: ['图表', '柱状图'] ,index:19},
          { key: '/app/chart/linechart', title: '折线图', icon: '', breadcrumb: ['图表', '折线图'],index:20 }
      ],
  },
];
const MyLoadingComponent = ({ isLoading, error }) => {
    // Handle the loading state
    if (isLoading) {
      return <div>Loading...</div>;
    }
    // Handle the error state
    else if (error) {
      return <div>Sorry, there was a problem loading the page.</div>;
    }
    else {
      return null;
    }
  };
const ReadMeJSX = Loadable({
    loader: () => import('../components/ui/ReadMe'),
    loading: MyLoadingComponent
  });
  const ButtonsJSX = Loadable({
    loader: () => import('../components/ui/Buttons'),
    loading: MyLoadingComponent
  });
  
  const IconsJSX = Loadable({
    loader: () => import('../components/ui/Icons'),
    loading: MyLoadingComponent
  });
  
  const ColorJSX = Loadable({
    loader: () => import('../components/ui/Colors'),
    loading: MyLoadingComponent
  });
  const FormElementJSX = Loadable({
    loader: () => import('../components/ui/FormElement'),
    loading: MyLoadingComponent
  });
  const DialogJSX = Loadable({
    loader: () => import('../components/ui/Dialog'),
    loading: MyLoadingComponent
  });
  
  const TabsJSX = Loadable({
    loader: () => import('../components/ui/Tabs'),
    loading: MyLoadingComponent
  });
  // const BasicForm = Loadable({
  //     loader: () => import('../components/forms/BasicForm'),
  //     loading: MyLoadingComponent
  // });
  
  const EchartJSX = Loadable({
    loader: () => import('../components/ui/Echart'),
    loading: MyLoadingComponent
  });
  
  const TableJSX = Loadable({
    loader: () => import('../components/ui/Table'),
    loading: MyLoadingComponent
  });
  
  const TagJSX = Loadable({
    loader: () => import('../components/ui/Tag'),
    loading: MyLoadingComponent
  });
  const ProgressJSX = Loadable({
    loader: () => import('../components/ui/Progress'),
    loading: MyLoadingComponent
  });
  const PaginationJSX = Loadable({
    loader: () => import('../components/ui/Pagination'),
    loading: MyLoadingComponent
  });
  const LoadingJSX = Loadable({
    loader: () => import('../components/ui/Loading'),
    loading: MyLoadingComponent
  });
  const MessageJSX = Loadable({
    loader: () => import('../components/ui/Message'),
    loading: MyLoadingComponent
  });
  const NotificationsJSX = Loadable({
    loader: () => import('../components/ui/Notifications'),
    loading: MyLoadingComponent
  });
  const BreadcrumbJSX = Loadable({
    loader: () => import('../components/ui/Breadcrumb'),
    loading: MyLoadingComponent
  });
  const StepJSX = Loadable({
    loader: () => import('../components/ui/Step'),
    loading: MyLoadingComponent
  });
  const MenuJSX = Loadable({
    loader: () => import('../components/ui/Menu'),
    loading: MyLoadingComponent
  });
  const DropdownJSX = Loadable({
    loader: () => import('../components/ui/Dropdown'),
    loading: MyLoadingComponent
  });
  
  const PieChartJSX = Loadable({
    loader: () => import('../components/ui/PieChart'),
    loading: MyLoadingComponent
  });
  
  const BarChartJSX = Loadable({
    loader: () => import('../components/ui/BarChart'),
    loading: MyLoadingComponent
  });
  
  const LineChartJSX = Loadable({
    loader: () => import('../components/ui/LineChart'),
    loading: MyLoadingComponent
  });
  
  const AnalysisJSX = Loadable({
    loader: () => import('../components/ui/Analysis'),
    loading: MyLoadingComponent
  });
  
  // const TESTJSX = Loadable({
  //   loader:()=>import('../components/ui/test'),
  //   loading: MyLoadingComponent
  // })

export const componentsJSXArray=[
    <AnalysisJSX />,
    <ReadMeJSX />,
    <ButtonsJSX/>,
    <IconsJSX />,
    <ColorJSX />,
    <LoadingJSX />,
    <MessageJSX />,
    <NotificationsJSX />,
    <DialogJSX />,
    <MenuJSX />,
    <TabsJSX />,
    <BreadcrumbJSX />,
    <DropdownJSX />,
    <StepJSX />,
    <TableJSX />,
    <TagJSX />,
    <ProgressJSX />,
    <PaginationJSX />,
    <PieChartJSX />,
    <BarChartJSX />,
    <LineChartJSX />,
    // <TESTJSX />,
]