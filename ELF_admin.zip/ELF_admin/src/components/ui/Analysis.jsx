import React from 'react';
import { Card, Tooltip, Tabs, Dropdown, Progress, Table, Pagination} from '../../ishow';
import Row from '../../ishow/LayoutComponent/row';
import Col from '../../ishow/LayoutComponent/col';
import PvChart from "./PvChart";
import HandleVolumnChart from "./HandleVolumnChart";
import ComplaintNumChart from "./ComplaintNumChart";
import PvBarChart from "./PvBarChart";
import SearchUserChart from "./SearchUserChart";
import AverageSearchChart from "./AverageSearchChart";
import AllChanelChart from "./AllChanelChart";
import ShopChart from "./ShopChart";

class Analysis extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            columns: [
                {
                    label: "用户数",
                    prop: "date",
                    // width: "180",
                    sortable: true
                },
                {
                    label: "周涨幅",
                    prop: "name",
                    // width: "180",
                    sortable: true
                },
                {
                    label: "搜索关键词",
                    prop: "address",
                },
                 {
                    label: "备注",
                    prop: "note",
                }
            ],
            data: [{
                date: '123',
                name: '3%',
                address: '九寨沟',
                note: '无'
            }, {
                date: '234',
                name: '5%',
                address: '西湖',
                note: '无'
            }, {
                date: '456',
                name: '0%',
                address: '布达拉宫',
                note: '无'
            }, 
            {
                date: '567',
                name: '10%',
                address: '大兴安岭',
                note: '无'
            }, 
            {
                date: '100',
                name: '1%',
                address: '乌兰沐统',
                note: '无'
            }],
            width:''
        }
    }

    /**
     * 访问量Tab页处于隐藏状态时，echarts图表不会自动显示为设置的大小，该方法提供触发
     * 点击访问量Tab页时触发
     * @param {any} tab 
     * @memberof Analysis
     */
    refreshChart(tab){
        this.setState({ width:'65%'})
    }

    render(){
        return (
            <div className="my-content">
            <Row type="flex" justify="space-between">
                <Col xs={12} sm={12} md={12} lg={12} xl={6}>
                <Card
                    className="box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px" }}>总投诉数</span>
                            <Tooltip className="info-icon" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                        </div>
                    }
                >
                    <div className="card-body">
                        <div className="card-body-text">1260</div>
                        <div className="card-body-chart" style={{ width: '100%', height: 40 }}>
                            周同比 12% <i className="ishow-icon-caret-bottom"></i>
                            &nbsp;&nbsp;
                            日环比 11% <i className="ishow-icon-caret-top"></i>
                        </div>
                    </div>
                    <div className="card-footer">
                        日均投诉量 666
                    </div>
                </Card>
                </Col>
                <Col xs={12} sm={12} md={12} lg={12} xl={6}>
                <Card
                    className="box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px" }}>访问量</span>
                            <Tooltip className="info-icon" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                        </div>
                    }
                >
                    <div className="card-body">
                        <div className="card-body-text">8848</div>
                        <div className="card-body-chart visited-num" style={{width:'100%',height:40}}>
                            <PvChart />
                        </div>
                    </div>
                    <div className="card-footer">
                        日均访问量 1234
                    </div>
                </Card>
                </Col>
                <Col xs={12} sm={12} md={12} lg={12} xl={6}>
                <Card
                    className="box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px" }}>处理量</span>
                            <Tooltip className="info-icon" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                        </div>
                    }
                >
                    <div className="card-body">
                        <div className="card-body-text">1001</div>
                        <div className="card-body-chart handled-num" style={{ width: '100%', height: 40 }}>
                            <HandleVolumnChart />
                        </div>
                    </div>
                    <div className="card-footer">
                        处理率 80%
                    </div>
                </Card>
                </Col>
                <Col xs={12} sm={12} md={12} lg={12} xl={6}>
                <Card
                    className="box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px" }}>处理效果</span>
                            <Tooltip className="info-icon" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                        </div>
                    }
                >
                    <div className="card-body">
                        <div className="card-body-text">78%</div>
                        <div className="card-body-chart effect-num" style={{ width: '100%', height: 40 }}>
                            <Progress percentage={78} />
                        </div>
                    </div>
                    <div className="card-footer">
                        周同比 12% <i className="ishow-icon-caret-bottom"></i>
                        &nbsp;&nbsp;
                        日环比 11% <i className="ishow-icon-caret-top"></i>
                    </div>
                </Card>
                </Col>
            </Row>
                <Tabs activeName="1" className="nav-menu" onTabClick={(tab)=>this.refreshChart(tab)}>
                    <Tabs.Pane label="投诉数" name="1" className="nav-menu-pane">
                        <ComplaintNumChart />
                        <div className="rank-list">
                            <h4>门店投诉数排名</h4>
                            <ul>
                                <li>
                                    <span className="no top3">1 </span>
                                    <span className="list-item">新街口商贸世纪店 </span>
                                    <span className="list-item-num">323 </span>
                                </li>
                                <li>
                                    <span className="no top3">2</span>
                                    <span className="list-item">鼓楼虹桥中心店</span>
                                    <span className="list-item-num">225</span>
                                </li>
                                <li>
                                    <span className="no top3">3</span>
                                    <span className="list-item">秦淮茂业天地门市</span>
                                    <span className="list-item-num">198</span>
                                </li>
                                <li>
                                    <span className="no">4</span>
                                    <span className="list-item">龙江金润发门市</span>
                                    <span className="list-item-num">134</span>
                                </li>
                                <li>
                                    <span className="no">5</span>
                                    <span className="list-item">江宁双龙大道门市</span>
                                    <span className="list-item-num">121</span>
                                </li>
                                <li>
                                    <span className="no">6</span>
                                    <span className="list-item">秦淮集庆路门市</span>
                                    <span className="list-item-num">109</span>
                                </li>
                                <li>
                                    <span className="no">7</span>
                                    <span className="list-item">鼓楼湛江路门市</span>
                                    <span className="list-item-num">101</span>
                                </li>
                            </ul>
                        </div>
                    </Tabs.Pane>
                    <Tabs.Pane label="访问量" name="2" >
                        <PvBarChart width={this.state.width}/> 
                        <div className="rank-list">
                            <h4>门店访问数排名</h4>
                            <ul>
                                <li>
                                    <span className="no top3">1 </span>
                                    <span className="list-item">新街口商贸世纪店 </span>
                                    <span className="list-item-num">323 </span>
                                </li>
                                <li>
                                    <span className="no top3">2</span>
                                    <span className="list-item">鼓楼虹桥中心店</span>
                                    <span className="list-item-num">225</span>
                                </li>
                                <li>
                                    <span className="no top3">3</span>
                                    <span className="list-item">秦淮茂业天地门市</span>
                                    <span className="list-item-num">198</span>
                                </li>
                                <li>
                                    <span className="no">4</span>
                                    <span className="list-item">龙江金润发门市</span>
                                    <span className="list-item-num">134</span>
                                </li>
                                <li>
                                    <span className="no">5</span>
                                    <span className="list-item">江宁双龙大道门市</span>
                                    <span className="list-item-num">121</span>
                                </li>
                                <li>
                                    <span className="no">6</span>
                                    <span className="list-item">秦淮集庆路门市</span>
                                    <span className="list-item-num">109</span>
                                </li>
                                <li>
                                    <span className="no">7</span>
                                    <span className="list-item">鼓楼湛江路门市</span>
                                    <span className="list-item-num">101</span>
                                </li>
                            </ul>
                        </div>
                    </Tabs.Pane> 
                </Tabs>
                
                <Card
                    className="big-box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px",marginLeft:"20px" }}>线上热门搜索</span>
                            <Dropdown menu={(
                                <Dropdown.Menu>
                                    <Dropdown.Item>选项一</Dropdown.Item>
                                    <Dropdown.Item>选项二</Dropdown.Item>
                                </Dropdown.Menu>
                            )}
                                className="ishow-dropdown-more"
                            >
                                <span className="ishow-dropdown-link">
                                    <i className="ishow-icon-more"></i>
                                </span>
                            </Dropdown>
                        </div>
                    }
                >
                    <div className="text item">
                        <div className="part-1">
                            <span>搜索用户数</span>
                            <Tooltip className="part-tooltip" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                            <div>
                                <span style={{fontSize:25,}}>12321</span>
                                <span> 17.1 <i className="ishow-icon-caret-top"></i></span>
                            </div>
                            <SearchUserChart />
                        </div>
                        <div className="part-2">
                            <span>人均搜索次数</span>
                            <Tooltip className="part-tooltip" effect="dark" content="指标说明" placement="top" >
                                <i className="ishow-icon-information"></i>
                            </Tooltip>
                            <div>
                                <span style={{ fontSize: 25, }}>2.7</span>
                                <span> 26.2 <i className="ishow-icon-caret-bottom"></i></span>
                            </div>
                            <AverageSearchChart />
                        </div>
                    </div>
                    <Table
                        style={{ width: '100%',height:'auto' }}
                        columns={this.state.columns}
                        data={this.state.data}
                        border={true}
                        highlightCurrentRow={true}
                    />
                    {/* <Pagination layout="prev, pager, next" total={this.state.columns.length} pageSize={5} small={true} style={{float:"right"}} /> */}
                </Card>

                <Card
                    className="big-box-card"
                    header={
                        <div className="clearfix">
                            <span style={{ "lineHeight": "36px",marginLeft:"20px" }}>销售额类别占比</span>
                            <Dropdown menu={(
                                <Dropdown.Menu>
                                    <Dropdown.Item>选项一</Dropdown.Item>
                                    <Dropdown.Item>选项二</Dropdown.Item>
                                </Dropdown.Menu>
                            )}
                                className="ishow-dropdown-more"
                            >
                                <span className="ishow-dropdown-link">
                                    <i className="ishow-icon-more"></i>
                                </span>
                            </Dropdown>
                        </div>
                    }
                >
                    <div className="text item">
                        <Tabs activeName="1" >
                            <Tabs.Pane label="全部渠道" name="1">
                                <AllChanelChart />
                            </Tabs.Pane>
                            <Tabs.Pane label="线上" name="2">线上</Tabs.Pane>
                            <Tabs.Pane label="门店" name="3">门店</Tabs.Pane>
                        </Tabs>
                    </div>
                    
                </Card>
                <br />
                <Tabs activeName="1">
                    <Tabs.Pane label="门店1" name="1">
                        <ShopChart />
                    </Tabs.Pane>
                    <Tabs.Pane label="门店2" name="2">门店2</Tabs.Pane>
                    <Tabs.Pane label="门店3" name="3">门店3</Tabs.Pane>
                    <Tabs.Pane label="门店4" name="4">门店4</Tabs.Pane>
                    <Tabs.Pane label="门店5" name="5">门店5</Tabs.Pane>
                    <Tabs.Pane label="门店6" name="6">门店6</Tabs.Pane>
                    <Tabs.Pane label="门店7" name="7">门店7</Tabs.Pane>
                    <Tabs.Pane label="门店8" name="8">门店8</Tabs.Pane>
                    <Tabs.Pane label="门店9" name="9">门店9</Tabs.Pane>
                </Tabs>

            </div>
        )
    }
}

export default Analysis