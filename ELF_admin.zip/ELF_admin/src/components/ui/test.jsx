import React, { Component } from 'react';
class App extends Component {
  render() {
    //for Collapse
    return (
      <div className="App">
        <h1>这里是新增加的test页面</h1>
      </div>
    );
  }
}
export default App;
