import React from 'react'
import ReactEcharts from 'echarts-for-react'

class Chart1 extends React.Component {
    getOption = () => {
        return {
            xAxis: {
                show: false,
                type: 'category',
                boundaryGap: false,
                data: ['3.15', '3.16', '3.17', '3.18', '3.19', '3.20', '3.21',"0"],
            },
            yAxis: {
                type: 'value',
                show: false,
            },
            tooltip: {
                show: true
            },
            series: [{
                data: [1620, 1332, 1131, 1234, 1228, 1133, 1230],
                type: 'line',
                areaStyle: {},
                smooth: true,
                color:"#58b7ff"
            }]
        };
    };

    render(){
        return(
            <ReactEcharts
                option={this.getOption()}
                style={{ height: '100px', width: '120%', top: '-30px'}}//这里的style控制的是echarts-for-react react_for_echarts
                className='react_for_echarts' />
        )
    }
}

export default Chart1