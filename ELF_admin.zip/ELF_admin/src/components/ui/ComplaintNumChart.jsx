import React from 'react'
import ReactEcharts from 'echarts-for-react'

class Chart3 extends React.Component {
    getOption = () => {
        return {
            xAxis: {
                type: 'category',
                data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            },
            yAxis: {
                type: 'value'
            },
            tooltip: {
                show: true
            },
            series: [{
                data: [120, 100, 150, 80, 70, 110, 130, 80, 70, 110, 130,120],
                type: 'bar',
                color:"#2da0ff"
            }]
        };
    };

    render() {
        return (
            <ReactEcharts
                option={this.getOption()}
                style={{ height: '300px', width: '65%' }}
                className='react_for_echarts chart3' />
        )
    }
}

export default Chart3