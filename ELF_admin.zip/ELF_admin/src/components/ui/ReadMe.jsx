import React,{ Component } from 'react';
//import Icon from '../../ishow/Icon/Icon';
export default class App extends Component{
    // componentDidMount(){
    //     //console.log(this.props);
    //     this.props.changeBread(['首页','控制台']);
    //   }
    
    render(){
        const code2 = `yarn install`;
        const code3 = `yarn start`;
        const code4 = `yarn build`;
        return(
            <div>
                <h1>iShow-Admin 途牛后台系统脚手架</h1>
                <h2 style={{marginTop:'20 !important'}}>介绍</h2>
                <ul style={{marginTop:20}}>
                    <li style={{listStyleType: 'circle',fontSize:16,marginBottom:10}}>途牛系统研发中心大前端团队（ElfTeam）提供的中后台系统脚手架</li>
                    <li style={{listStyleType: 'circle',fontSize:16,marginBottom:10}}>iShow Admin致力于在公共的设计规范和基础组件的基础上，进一步提升中后台产品设计研发过程中的开发工程师的体验。随着不断反馈，我们将持续迭代，逐步沉淀和总结出更多设计模式和相应的代码实现。</li>
                    <li style={{listStyleType: 'circle',fontSize:16,marginBottom:10}}>我们的目标是维护一个JSON配置文件即可生成左边这样的后台模板，并据此构建了一套基于 React 的中后台管理控制台的脚手架，它可以帮助你快速搭建企业级中后台产品原型。</li>
                </ul>
                <h2 style={{marginTop:'20 !important'}}>使用方法</h2>
                <ul style={{marginTop:20}}>
                         <pre>
                         <p style={{color:'#1D8CE0',fontFamily:'microsoft yahei',fontSize:16,fontWeight:'bold'}}>您可使用淘宝镜像安装：cnpm install iShow-Admin<i style={{color:'gray'}}>（暂未开通，敬请期待）</i></p>
                            <p style={{color:'#1D8CE0',fontFamily:'microsoft yahei',fontSize:16,fontWeight:'bold'}}>使用iShow-Admin，您需要执行如下命令：</p>
                            <code style={{color:'green'}}><p style={{margin:10}}>{code2}</p><p style={{margin:10}}>{code3}</p><p style={{margin:10}}>{code4}</p></code>                                           
                            <p style={{color:'#1D8CE0',fontFamily:'microsoft yahei',fontSize:16,fontWeight:'bold'}}>ELF-Admin使用方法：</p>
                            <p style={{color:'#1D8CE0',fontFamily:'microsoft yahei',fontSize:14}}>仅需配置该菜单的json文件</p>
                            <div><img src='./menulist.png' alt='menulist.png'/></div>
                        </pre> 
                </ul>
                <h2 style={{marginTop:'20 !important'}}>浏览器兼容性</h2>
                <div style={{marginLeft:'40px'}}>
                <p style={{color:'#1D8CE0',fontFamily:'microsoft yahei',fontSize:16,fontWeight:'bold'}}>再更低版本的浏览器兼容之前，我们建议您使用如下版本及以上的浏览器，以确保我们的页面正常展示。</p>
                <table className="compatible_table" style={{borderCollapse:'collapse',textAlign:'center',margin:'20px 0'}}>
                    <thead style={{borderCollapse:'collapse'}}>
                    <tr>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}><img src="./compatible_chrome.gif" alt=""/></td>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}><img src="./compatible_firefox.gif" alt=""/></td>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}><img src="./compatible_ie.gif" alt=""/></td>
                    </tr>
                    </thead>
                    <tbody style={{borderCollapse:'collapse'}}>
                    <tr>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}>Chrome 54+</td>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}>FireFox 43+</td>
                        <td style={{border:'1px solid #999',borderCollapse:'collapse',padding:'10px'}}>IE 10+</td>
                    </tr>
                    </tbody>
                </table>
                </div>
                <h2 style={{marginTop:'20 !important'}}>更新日志</h2>
                <ul style={{marginTop:20,listStyle:'none',color:'#606266'}}>
                <li><a href="http://wiki.tuniu.org/pages/viewpage.action?pageId=83331993">http://wiki.tuniu.org/pages/viewpage.action?pageId=83331993</a></li>
                </ul>
                <h2 style={{marginTop:'20 !important'}}>联系我们</h2>
                <ul style={{marginTop:20,listStyle:'none',color:'#606266'}}>
                    <li>前端研发部：<a href="mailto:zhangyong5@tuniu.com">zhangyong5@tuniu.com</a></li>
                </ul>
            </div>
        );
    }

}