export const CodeList = {
    Button: {
        Code: [
            `render() {
                return (
                  <div>
                    <Button>普通按钮</Button>
                    <Button type="primary">主要按钮</Button>
                    <Button type="text">文字按钮</Button>
                  </div>
                )
              }`,
            `render() {
                return (
                  <div>
                    <Button plain={true} disabled={true}>普通按钮</Button>
                    <Button type="primary" disabled={true}>主要按钮</Button>
                    <Button type="text" disabled={true}>文字按钮</Button>
                  </div>
                )
              }`,
            `render() {
                return <Button type="primary" loading={true}>加载中</Button>
              }`,
            `render() {
                return (
                  <div >
                        <Button type="success">成功按钮</Button>
                        <Button type="warning">警告按钮</Button>
                        <Button type="danger">危险按钮</Button>
                        <Button type="info">信息按钮</Button>
                        <Button plain={true} type="success">成功按钮</Button>
                        <Button plain={true} type="warning">警告按钮</Button>
                        <Button plain={true} type="danger">危险按钮</Button>
                        <Button plain={true} type="info">信息按钮</Button>
                  </div>
                )
              }`,
            `render() {
                return (
                  <div>
                    <Button type="primary" icon="edit"></Button>
                    <Button type="primary" icon="share"></Button>
                    <Button type="primary" icon="delete"></Button>
                    <Button type="primary" icon="search">搜索</Button>
                    <Button type="primary">上传<i className="ishow-icon-upload ishow-icon-right"></i></Button>
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Button.Group>
                        <Button type="primary" icon="arrow-left">上一页</Button>
                        <Button type="primary">下一页<i className="ishow-icon-arrow-right ishow-icon-right"></i></Button>
                    </Button.Group>
                    <Button.Group>
                        <Button type="primary" icon="edit"></Button>
                        <Button type="primary" icon="share"></Button>
                        <Button type="primary" icon="delete"></Button>
                    </Button.Group>
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Button type="primary" size="large">大型按钮</Button>
                    <Button type="primary">正常按钮</Button>
                    <Button type="primary" size="small">小型按钮</Button>
                    <Button type="primary" size="mini">超小按钮</Button>
                  </div>
                )
              }
              `
        ]
    },
    Icon: {
        Code: [
            `render() {
                return (
                  <div>
                    <i className="ishow-icon-edit"></i>
                    <i className="ishow-icon-share"></i>
                    <i className="ishow-icon-delete"></i>
                    <Button type="primary" icon="search">搜索</Button>
                  </div>
                )
              }
              `
        ]
    },
    Radio: {
        Code: [
            `constructor(props) {
                super(props);
              
                this.state = {
                  value: 1
                }
              }
              
              onChange(value) {
                this.setState({ value });
              }
              
              render() {
                return (
                  <div>
                    <Radio value="1" checked={this.state.value === 1} onChange={this.onChange.bind(this)}>ELF-zhangyong</Radio>
                    <Radio value="2" checked={this.state.value === 2} onChange={this.onChange.bind(this)}>ELF-chenyuting</Radio>
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Radio value="1" disabled={true}>ELF-zhangyong</Radio>
                    <Radio value="2" disabled={true}>ELF-chenyuting</Radio>
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  value: 3
                }
              }
              
              onChange(value) {
                this.setState({ value });
              }
              
              render() {
                return (
                  <Radio.Group value={this.state.value} onChange={this.onChange.bind(this)}>
                      <Radio value="zy">张勇</Radio>
                      <Radio value="tyy">唐媛媛</Radio>
                      <Radio value="cyt">陈瑜婷</Radio>
                      <Radio value="zph">赵斐昊</Radio>
                      <Radio value="sy">盛瑜</Radio>
                      <Radio value="hj">黄杰</Radio>
                      <Radio value="lx">刘兴</Radio>
                      <Radio value="lzq">刘泽琼</Radio>
                  </Radio.Group>
                )
              }
              `
        ]
    },

    Checkbox: {
        Code: [
            `render() {
                return <Checkbox checked>备选项</Checkbox>
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  checkList: ['复选框 A', '选中且禁用']
                }
              }
              render() {
                return (
                  <Checkbox.Group value={this.state.checkList}>
                    <Checkbox label="复选框 A"></Checkbox>
                    <Checkbox label="复选框 B"></Checkbox>
                    <Checkbox label="复选框 C"></Checkbox>
                    <Checkbox label="禁用" disabled></Checkbox>
                    <Checkbox label="选中且禁用" disabled></Checkbox>
                  </Checkbox.Group>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  checkAll: false,
                  cities: ['江苏', '北京', '广州', '深圳'],
                  checkedCities: ['江苏', '北京'],
                  isIndeterminate: true,
                }
              }
              
              handleCheckAllChange(checked) {
                const checkedCities = checked ? ['江苏', '北京', '广州', '深圳'] : [];
              
                this.setState({
                  isIndeterminate: false,
                  checkAll: checked,
                  checkedCities: checkedCities,
                });
              }
              
              handleCheckedCitiesChange(value) {
                const checkedCount = value.length;
                const citiesLength = this.state.cities.length;
              
                this.setState({
                  checkedCities: value,
                  checkAll: checkedCount === citiesLength,
                  isIndeterminate: checkedCount > 0 && checkedCount < citiesLength,
                });
              }
              
              render() {
                return (
                  <div>
                    <Checkbox
                      checked={this.state.checkAll}
                      indeterminate={this.state.isIndeterminate}
                      onChange={this.handleCheckAllChange.bind(this)}>全选</Checkbox>
                    <div style={{margin: '15px 0'}}></div>
                    <Checkbox.Group
                      value={this.state.checkedCities}
                      onChange={this.handleCheckedCitiesChange.bind(this)}>
                      {
                        this.state.cities.map((city, index) =>
                          <Checkbox key={index} label={city}></Checkbox>
                        )
                      }
                    </Checkbox.Group>
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  checkAll: false,
                  cities: ['江苏', '北京', '广州', '深圳'],
                  checkedCities: ['江苏', '北京'],
                  isIndeterminate: true,
                }
              }
              
              handleCheckAllChange(checked) {
                const checkedCities = checked ? ['江苏', '北京', '广州', '深圳'] : [];
              
                this.setState({
                  isIndeterminate: false,
                  checkAll: checked,
                  checkedCities: checkedCities,
                });
              }
              
              handleCheckedCitiesChange(value) {
                const checkedCount = value.length;
                const citiesLength = this.state.cities.length;
              
                this.setState({
                  checkedCities: value,
                  checkAll: checkedCount === citiesLength,
                  isIndeterminate: checkedCount > 0 && checkedCount < citiesLength,
                });
              }
              
              render() {
                return (
                  <div>
                    <Checkbox
                      checked={this.state.checkAll}
                      indeterminate={this.state.isIndeterminate}
                      onChange={this.handleCheckAllChange.bind(this)}>全选</Checkbox>
                    <div style={{margin: '15px 0'}}></div>
                    <Checkbox.Group
                      min="1"
                      max="2"
                      value={this.state.checkedCities}
                      onChange={this.handleCheckedCitiesChange.bind(this)}>
                      {
                        this.state.cities.map((city, index) =>
                          <Checkbox key={index} label={city}></Checkbox>
                        )
                      }
                    </Checkbox.Group>
                  </div>
                )
              }
              `
        ]
    },
    Input: {
        Code: [
            `render() {
                return <Input placeholder="请输入内容" />
              }
              `,
            `render() {
                return <Input disabled placeholder="请输入内容" />
              }
              `,
            `handleIconClick(ev) {

            }
            
            render() {
              return (
                <Input
                  icon="time"
                  placeholder="请选择日期"
                  onIconClick={this.handleIconClick.bind(this)}
                />
              )
            }
            `,
            `render() {
                return (
                  <div>
                    <Input
                      type="textarea"
                      autosize={true}
                      placeholder="请输入内容"
                    />
                    <div style={{ margin: '20px 0' }}></div>
                    <Input
                      type="textarea"
                      autosize={{ minRows: 2, maxRows: 4}}
                      placeholder="请输入内容"
                    />
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Input placeholder="请输入内容" prepend="Http://" />
                    <Input placeholder="请输入内容" append=".com" />
                    <Input placeholder="请输入内容" prepend={
                      <Select value="">
                        {
                          ['餐厅名', '订单号', '用户电话'].map((item, index) => <Select.Option key={index} label={item} value={index} />)
                        }
                      </Select>
                    } append={<Button type="primary" icon="search">搜索</Button>} />
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div className="inline-input">
                    <Input placeholder="请输入内容" size="large" />
                    <Input placeholder="请输入内容" />
                    <Input placeholder="请输入内容" size="small" />
                    <Input placeholder="请输入内容" size="mini" />
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  restaurants: [
                    { "value": "三全鲜食（北新泾店）", "address": "长宁区新渔路144号" },
                    { "value": "Hot honey 首尔炸鸡（仙霞路）", "address": "江苏市长宁区淞虹路661号" },
                    { "value": "新旺角茶餐厅", "address": "上海迪士尼乐园988号创邑金沙谷6号楼113" },
                    { "value": "泷千家(天山西路店)", "address": "天山西路438号" },
                    { "value": "胖仙女纸杯蛋糕（江苏凌空店）", "address": "江苏市长宁区金钟路968号1幢18号楼一层商铺18-101" },
                    { "value": "贡茶", "address": "江苏市长宁区金钟路633号" },
                    { "value": "豪大大香鸡排超级奶爸", "address": "江苏市嘉定区曹安公路曹安路1685号" },
                    { "value": "茶芝兰（奶茶，手抓饼）", "address": "江苏市南京同普路1435号" },
                    { "value": "十二泷町", "address": "江苏市北翟路1444弄81号B幢-107" },
                    { "value": "星移浓缩咖啡", "address": "江苏市嘉定区新郁路817号" },
                    { "value": "阿姨奶茶/豪大大", "address": "嘉定区曹安路1611号" },
                    { "value": "新麦甜四季甜品炸鸡", "address": "嘉定区曹安公路2383弄55号" },
                    { "value": "Monica摩托主题咖啡店", "address": "嘉定区江桥镇曹安公路2409号1F，2383弄62号1F" },
                    { "value": "浮生若茶（凌空soho店）", "address": "江苏长宁区金钟路968号9号楼地下一层" },
                    { "value": "NONO JUICE  鲜榨果汁", "address": "江苏市长宁区天山西路119号" },
                    { "value": "CoCo都可(北新泾店）", "address": "江苏市长宁区仙霞西路" },
                    { "value": "快乐柠檬（神州智慧店）", "address": "江苏市长宁区天山西路567号1层R117号店铺" },
                    { "value": "Merci Paul cafe", "address": "江苏市南京光复西路丹巴路28弄6号楼819" },
                    { "value": "猫山王（西郊百联店）", "address": "江苏市长宁区仙霞西路88号第一层G05-F01-1-306" },
                    { "value": "枪会山", "address": "江苏市南京棕榈路" },
                    { "value": "纵食", "address": "元丰天山花园(东门) 双流路267号" },
                    { "value": "钱记", "address": "江苏市长宁区天山西路" },
                    { "value": "壹杯加", "address": "江苏市长宁区通协路" },
                    { "value": "唦哇嘀咖", "address": "江苏市长宁区新泾镇金钟路999号2幢（B幢）第01层第1-02A单元" },
                    { "value": "爱茜茜里(西郊百联)", "address": "长宁区仙霞西路88号1305室" },
                    { "value": "爱茜茜里(近铁广场)", "address": "上海迪士尼乐园818号近铁城市广场北区地下二楼N-B2-O2-C商铺" },
                    { "value": "鲜果榨汁（金沙江路和美广店）", "address": "南京金沙江路2239号金沙和美广场B1-10-6" },
                    { "value": "开心丽果（缤谷店）", "address": "江苏市长宁区威宁路天山路341号" },
                    { "value": "超级鸡车（丰庄路店）", "address": "江苏市嘉定区丰庄路240号" },
                    { "value": "妙生活果园（北新泾店）", "address": "长宁区新渔路144号" },
                    { "value": "香宜度麻辣香锅", "address": "长宁区淞虹路148号" },
                    { "value": "凡仔汉堡（老真北路店）", "address": "江苏市南京老真北路160号" },
                    { "value": "港式小铺", "address": "江苏市长宁区金钟路968号15楼15-105室" },
                    { "value": "蜀香源麻辣香锅（剑河路店）", "address": "剑河路443-1" },
                    { "value": "北京饺子馆", "address": "长宁区北新泾街道天山西路490-1号" },
                    { "value": "饭典*新简餐（凌空SOHO店）", "address": "江苏市长宁区金钟路968号9号楼地下一层9-83室" },
                    { "value": "焦耳·川式快餐（金钟路店）", "address": "江苏市金钟路633号地下一层甲部" },
                    { "value": "动力鸡车", "address": "长宁区仙霞西路299弄3号101B" },
                    { "value": "浏阳蒸菜", "address": "天山西路430号" },
                    { "value": "四海游龙（天山西路店）", "address": "江苏市长宁区天山西路" },
                    { "value": "樱花食堂（凌空店）", "address": "江苏市长宁区金钟路968号15楼15-105室" },
                    { "value": "壹分米客家传统调制米粉(天山店)", "address": "天山西路428号" },
                    { "value": "福荣祥烧腊（平溪路店）", "address": "江苏市长宁区协和路福泉路255弄57-73号" },
                    { "value": "速记黄焖鸡米饭", "address": "江苏市长宁区北新泾街道金钟路180号1层01号摊位" },
                    { "value": "红辣椒麻辣烫", "address": "江苏市长宁区天山西路492号" },
                    { "value": "(小杨生煎)西郊百联餐厅", "address": "长宁区仙霞西路88号百联2楼" },
                    { "value": "阳阳麻辣烫", "address": "天山西路389号" },
                    { "value": "南拳妈妈龙虾盖浇饭", "address": "南京金沙江路1699号鑫乐惠美食广场A13" }
                  ],
                  value1: '',
                  value2: ''
                }
              }
              
              querySearch(queryString, cb) {
                const { restaurants } = this.state;
                const results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
                // 调用 callback 返回建议列表的数据
                cb(results);
              }
              
              createFilter(queryString) {
                return (restaurant) => {
                  return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
                };
              }
              
              handleSelect(item) {
              
              }
              
              render() {
                return (
                  <Layout.Row className="inline-input border-grid">
                    <Layout.Col span="12" className="tac">
                      <div className="text">激活即列出输入建议</div>
                      <AutoComplete
                        placeholder="请输入内容"
                        value={this.state.value1}
                        onFocus={e=>console.log(e, 'onFocus')}
                        onBlur={e=>console.log(e, 'onblur')}
                        fetchSuggestions={this.querySearch.bind(this)}
                        onSelect={this.handleSelect.bind(this)}
                      ></AutoComplete>
                    </Layout.Col>
                    <Layout.Col span="12" className="tac">
                      <div className="text">输入后匹配输入建议</div>
                      <AutoComplete
                        placeholder="请输入内容"
                        value={this.state.value2}
                        fetchSuggestions={this.querySearch.bind(this)}
                        onSelect={this.handleSelect.bind(this)}
                        triggerOnFocus={false}
                      ></AutoComplete>
                    </Layout.Col>
                  </Layout.Row>
                )
              }
              `
        ]
    },
    Select: {
        Code: [
            `constructor(props) {
                super(props);
              
                this.state = {
                  options: [{
                    value: '选项1',
                    label: 'ELF-张勇'
                  }, {
                    value: '选项2',
                    label: 'ELF-陈瑜婷'
                  }, {
                    value: '选项3',
                    label: 'ELF-盛瑜'
                  }, {
                    value: '选项4',
                    label: 'ELF-刘兴'
                  }, {
                    value: '选项5',
                    label: 'ELF-黄杰'
                  },
                  {
                    value: '选项6',
                    label: 'ELF-刘泽琼'
                  },
                  {
                    value: '选项7',
                    label: 'ELF-赵斐昊'
                  }],
                  value: ''
                };
              }
              
              render() {
                return (
                  <Select value={this.state.value}>
                    {
                      this.state.options.map(el => {
                        return <Select.Option key={el.value} label={el.label} value={el.value} />
                      })
                    }
                  </Select>
                )
              }
              `
        ]
    },
    Switch: {
        Code: [
            `render() {
                return (
                  <div>
                    <Switch
                      value={true}
                      onText=""
                      offText="">
                    </Switch>
                    <Switch
                      value={true}
                      onColor="#13ce66"
                      offColor="#ff4949">
                    </Switch>
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  value: 100,
                }
              }
              
              render() {
                return (
                  <Tooltip
                    placement="top"
                    content={
                      <div>Switch value: {this.state.value}</div>
                    }
                  >
                    <Switch
                      value={this.state.value}
                      onColor="#13ce66"
                      offColor="#ff4949"
                      onValue={100}
                      offValue={0}
                      onChange={(value)=>{this.setState({value: value})}}
                     >
                    </Switch>
                  </Tooltip>
                )
              }
              `
        ]
    },
    DatePicker: {
        Code: [
            `
            constructor(props) {
              super(props)
              this.state = {}
            }
            
            render() {
              const {value1, value2} = this.state
            
              return (
                <div>
                  <div>
                    <DatePicker
                      value={value1}
                      placeholder="选择日期"
                      onChange={date=>{
                        console.debug('DatePicker1 changed: ', date)
                        this.setState({value1: date})
                      }}
                      disabledDate={time=>time.getTime() < Date.now() - 8.64e7}
                      />
                  </div>
                  <div>
                    <span className="demonstration">带快捷选项</span>
                    <DatePicker
                      ref={e=>this.datepicker2 = e}
                      value={value2}
                      align="right"
                      placeholder="选择日期"
                      onChange={date=>{
                        console.debug('DatePicker2 changed: ', date)
                        this.setState({value2: date})
            
                      }}
                      shortcuts={[{
                        text: '今天',
                        onClick: (picker)=> {
                          this.setState({value2: new Date()})
                          this.datepicker2.togglePickerVisible()
                        }
                      }, {
                        text: '昨天',
                        onClick: (picker)=> {
                          const date = new Date();
                          date.setTime(date.getTime() - 3600 * 1000 * 24);
                          this.setState({value2: date})
                          this.datepicker2.togglePickerVisible()
                        }
                      }, {
                        text: '一周前',
                        onClick: (picker)=> {
                          const date = new Date();
                          date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                          this.setState({value2: date})
                          this.datepicker2.togglePickerVisible()
                        }
                      }]}
                      />
                  </div>
                </div>
              )
            }
            
            `,
            `constructor(props) {
                super(props)
                this.state = {value1: null, value2: null}
              }
              
              render() {
                const {value1, value2} = this.state
              
                return (
                  <div>
                    <div>
                      <DateRangePicker
                        value={value1}
                        placeholder="选择日期范围"
                        onChange={date=>{
                          console.debug('DateRangePicker1 changed: ', date)
                          this.setState({value1: date})
                        }}
                        />
                    </div>
                    <div>
                      <DateRangePicker
                        value={value2}
                        placeholder="选择日期范围"
                        align="right"
                        ref={e=>this.daterangepicker2 = e}
                        onChange={date=>{
                          console.debug('DateRangePicker2 changed: ', date)
                          this.setState({value2: date})
                        }}
                        shortcuts={[{
                          text: '最近一周',
                          onClick: ()=> {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              
                            this.setState({value2: [start, end]})
                            this.daterangepicker2.togglePickerVisible()
                          }
                        }, {
                          text: '最近一个月',
                          onClick: ()=> {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              
                            this.setState({value2: [start, end]})
                            this.daterangepicker2.togglePickerVisible()
                          }
                        }, {
                          text: '最近三个月',
                          onClick: ()=> {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            this.setState({value2: [start, end]})
                            this.daterangepicker2.togglePickerVisible()
                          }
                        }]}
                        />
                    </div>
                  </div>
                )
              }
              
              `
        ]
    },
    Upload: {
        Code: [
            `render() {
                const fileList = [
                  {name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg'}
                ];
                return (
                  <Upload
                    className="upload-demo"
                    action="//jsonplaceholder.typicode.com/posts/"
                    onPreview={file => this.handlePreview(file)}
                    onRemove={(file, fileList) => this.handleRemove(file, fileList)}
                    fileList={fileList}
                    tip={<div className="ishow-upload__tip">只能上传jpg/png文件，且不超过500kb</div>}
                  >
                    <Button size="small" type="primary">点击上传</Button>
                  </Upload>
                )
              }
              
              handlePreview(file) {
                console.log('preview');
              }
              
              handleRemove(file, fileList) {
                console.log('remove');
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  dialogImageUrl: '',
                  dialogVisible: false,
                };
              }
              
              render() {
                const { dialogImageUrl, dialogVisible } = this.state;
                return (
                  <div>
                    <Upload
                      action="//jsonplaceholder.typicode.com/posts/"
                      listType="picture-card"
                      onPreview={file => this.handlePictureCardPreview(file)}
                      onRemove={(file, fileList) => this.handleRemove(file, fileList)}
                    >
                      <i className="ishow-icon-plus"></i>
                    </Upload>
                    <Dialog
                      visible={dialogVisible}
                      size="tiny"
                      onCancel={() => this.setState({ dialogVisible: false })}
                    >
                      <img width="100%" src={dialogImageUrl} alt="" />
                    </Dialog>
                  </div>
                )
              }
              
              handleRemove(file, fileList) {
                console.log(file, fileList);
              }
              
              handlePictureCardPreview(file) {
                this.setState({
                  dialogImageUrl: file.url,
                  dialogVisible: true,
                })
              }
              
              `,
            `render() {
                const fileList2 = [
                  {name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg'}
                ]
                return (
                  <Upload
                    className="upload-demo"
                    action="//jsonplaceholder.typicode.com/posts/"
                    onPreview={file => this.handlePreview(file)}
                    onRemove={(file, fileList) => this.handleRemove(file, fileList)}
                    fileList={fileList2}
                    listType="picture"
                    tip={<div className="ishow-upload__tip">只能上传jpg/png文件，且不超过500kb</div>}
                  >
                    <Button size="small" type="primary">点击上传</Button>
                  </Upload>
                )
              }
              
              handleRemove(file, fileList) {
                console.log(file, fileList);
              }
              
              handlePreview(file) {
                console.log(file);
              }
              
              `
        ]
    },
    Table: {
        Code: [
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 180
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 180
                    },
                    {
                      label: "地址",
                      prop: "address"
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  },{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    maxHeight={200}
                    data={this.state.data}
                    stripe={true}
                    border={true}
                  />
                )
              }
              `,
            `   render() {
              return (
                <Table
                style={{width: '60%'}}
                columns={this.state.columns2}
                data={this.state.data2}
                border={true}
                height={200}
              />
              )
            }`,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 150
                    },
                    {
                      label: "配送信息",
                      subColumns: [
                        {
                          label: "姓名",
                          prop: "name",
                          width: 160
                        },
                        {
                          label: "地址",
                          subColumns: [
                            {
                              label: "省份",
                              prop: "province",
                              width: 160
                            },
                            {
                              label: "城市",
                              prop: "address",
                              width: 400
                            },
                            {
                              label: "邮编",
                              prop: "zip",
                              width: 120
                            }
                          ]
                        }
                      ]
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                  }]
                }
              }
              
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={true}
                  />
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      type: 'index'
                    },
                    {
                      label: "日期",
                      prop: "date",
                      width: 150,
                      render: function(data){
                        return (
                        <span>
                          <Icon name="time"/>
                          <span style={{marginLeft: '10px'}}>{data.date}</span>
                        </span>)
                      }
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 160,
                      render: function(data){
                        return <Tag>{data.name}</Tag>
                      }
                    },
                    {
                      label: "操作",
                      prop: "address",
                      render: function(){
                        return (
                          <span>
                           <Button plain={true} type="info" size="small">编辑</Button>
                           <Button type="danger" size="small">删除</Button>
                          </span>
                        )
                      }
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={true}
                    height={250}
                    highlightCurrentRow={true}
                    onCurrentChange={item=>{console.log(item)}}
                  />
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      type: 'expand',
                      expandPannel: function(data){
                        return (
                          <Form labelPosition="left" inline={true} className="demo-table-expand">
                            <Form.Item label="商品名称"><span>双人报价套餐-上海迪士尼乐园自驾2日游</span></Form.Item>
                            <Form.Item label="所属店铺"><span>途牛大前端 -- 张勇夫妻店</span></Form.Item>
                            <Form.Item label="商品 ID"><span>12987122</span></Form.Item>
                            <Form.Item label="店铺 ID"><span>10333</span></Form.Item>
                            <Form.Item label="商品分类"><span>宿玩具总动员酒店</span></Form.Item>
                            <Form.Item label="店铺地址"><span>上海迪士尼乐园</span></Form.Item>
                            <Form.Item label="商品描述"><span>3月5号至7号预定指定团期迪士尼门票享七五折特惠名额有限</span></Form.Item>
                          </Form>
                        )
                      }
                    },
                    {
                      label: "商品 ID",
                      prop: "id",
                      width: 150
                    },
                    {
                      label: "商品名称",
                      prop: "name",
                      width: 160
                    },
                    {
                      label: "描述",
                      prop: "desc"
                    }
                  ],
                  data: [{
                    id: '12987122',
                    name: '双人报价套餐-上海迪士尼乐园自驾2日游',
                    category: '宿玩具总动员酒店',
                    desc: '3月5号至7号预定指定团期迪士尼门票享七五折特惠名额有限',
                    address: '上海迪士尼乐园',
                    shop: '途牛大前端 -- 张勇夫妻店',
                    shopId: '10333'
                  }, {
                    id: '12987123',
                    name: '双人报价套餐-上海迪士尼乐园自驾2日游',
                    category: '宿玩具总动员酒店',
                    desc: '3月5号至7号预定指定团期迪士尼门票享七五折特惠名额有限',
                    address: '上海迪士尼乐园',
                    shop: '途牛大前端 -- 张勇夫妻店',
                    shopId: '10333'
                  }, {
                    id: '12987125',
                    name: '双人报价套餐-上海迪士尼乐园自驾2日游',
                    category: '宿玩具总动员酒店',
                    desc: '3月5号至7号预定指定团期迪士尼门票享七五折特惠名额有限',
                    address: '上海迪士尼乐园',
                    shop: '途牛大前端 -- 张勇夫妻店',
                    shopId: '10333'
                  }, {
                    id: '12987126',
                    name: '双人报价套餐-上海迪士尼乐园自驾2日游',
                    category: '宿玩具总动员酒店',
                    desc: '3月5号至7号预定指定团期迪士尼门票享七五折特惠名额有限',
                    address: '上海迪士尼乐园',
                    shop: '途牛大前端 -- 张勇夫妻店',
                    shopId: '10333'
                  }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={false}
                    onCurrentChange={item=>{console.log(item)}}
                  />
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      type: 'selection'
                    },
                    {
                      label: "日期",
                      prop: "date",
                      width: 150
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 160
                    },
                    {
                      label: "地址",
                      prop: "address"
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }, {
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    province: '江苏',
                    city: '南京',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    zip: 200333
                   }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={true}
                    height={250}
                    onSelectChange={(selection) => { console.log(selection) }}
                    onSelectAll={(selection) => { console.log(selection) }}
                  />
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 180,
                      sortable: true
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 180,
                      sortable: true
                    },
                    {
                      label: "地址",
                      prop: "address"
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={true}
                  />
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 180
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 180
                    },
                    {
                      label: "地址",
                      prop: "address"
                    },
                    {
                      label: '标签',
                      prop: 'tag',
                      width: 100,
                      filters: [{text: '家', value: '家'}, {text: '公司', value: '公司'}],
                      filterMethod(value, row) {
                                return row.tag === value;
                              },
                      render: (data, column)=>{
                        if(data['tag'] == '家'){
                          return <Tag type="primary">{data['tag']}</Tag>
                        }else if(data['tag'] == '公司'){
                          return <Tag type="success">{data['tag']}</Tag>
                        }
                      }
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    tag: '家'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    tag: '公司'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    tag: '公司'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦',
                    tag: '家'
                  }]
                }
              }
              
              render() {
                return (
                  <Table
                    style={{width: '100%'}}
                    columns={this.state.columns}
                    data={this.state.data}
                    border={true}
                  />
                )
              }
              `
        ]
    },
    Tag: {
        Code: [
            `render() {
                return (
                  <div>
                    <Tag>标签一</Tag>
                    <Tag type="gray">标签二</Tag>
                    <Tag type="primary">标签三</Tag>
                    <Tag type="success">标签四</Tag>
                    <Tag type="warning">标签五</Tag>
                    <Tag type="danger">标签六</Tag>
                  </div>
                )
              }`,
            `constructor(props) {
                super(props);
              
                this.state = {
                  tags: [
                    { key: 1, name: '标签一', type: '' },
                    { key: 2, name: '标签二', type: 'gray' },
                    { key: 5, name: '标签三', type: 'primary' },
                    { key: 3, name: '标签四', type: 'success' },
                    { key: 4, name: '标签五', type: 'warning' },
                    { key: 6, name: '标签六', type: 'danger' }
                  ]
                }
              }
              
              handleClose(tag) {
                const { tags } = this.state;
              
                tags.splice(tags.map(el => el.key).indexOf(tag.key), 1);
              
                this.setState({ tag });
              }
              
              render() {
                return (
                  <div>
                    {
                      this.state.tags.map(tag => {
                        return (
                          <Tag
                            key={tag.key}
                            closable={true}
                            type={tag.type}
                            closeTransition={false}
                            onClose={this.handleClose.bind(this, tag)}>{tag.name}</Tag>
                        )
                      })
                    }
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  dynamicTags: ['标签一', '标签二', '标签三'],
                  inputVisible: false,
                  inputValue: ''
                }
              }
              
              onKeyUp(e) {
                if (e.keyCode === 13) {
                  this.handleInputConfirm();
                }
              }
              
              onChange(value) {
                this.setState({ inputValue: value });
              }
              
              handleClose(index) {
                this.state.dynamicTags.splice(index, 1);
                this.forceUpdate();
              }
              
              showInput() {
                this.setState({ inputVisible: true }, () => {
                  this.refs.saveTagInput.focus();
                });
              }
              
              handleInputConfirm() {
                let inputValue = this.state.inputValue;
              
                if (inputValue) {
                  this.state.dynamicTags.push(inputValue);
                }
              
                this.state.inputVisible = false;
                this.state.inputValue = '';
              
                this.forceUpdate();
              }
              
              render() {
                return (
                  <div>
                    {
                      this.state.dynamicTags.map((tag, index) => {
                        return (
                          <Tag
                            key={Math.random()}
                            closable={true}
                            closeTransition={false}
                            onClose={this.handleClose.bind(this, index)}>{tag}</Tag>
                        )
                      })
                    }
                    {
                      this.state.inputVisible ? (
                        <Input
                          className="input-new-tag"
                          value={this.state.inputValue}
                          ref="saveTagInput"
                          size="mini"
                          onChange={this.onChange.bind(this)}
                          onKeyUp={this.onKeyUp.bind(this)}
                          onBlur={this.handleInputConfirm.bind(this)}
                        />
                      ) : <Button className="button-new-tag" size="small" onClick={this.showInput.bind(this)}>+ New Tag</Button>
                    }
                  </div>
                )
              }
              `
        ]
    },
    Progress: {
        Code: [
            `render() {
                return (
                  <div>
                    <Progress percentage={0} />
                    <Progress percentage={70} />
                    <Progress percentage={100} status="success" />
                    <Progress percentage={50} status="exception" />
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Progress strokeWidth={18} percentage={0} textInside />
                    <Progress strokeWidth={18} percentage={70} textInside />
                    <Progress strokeWidth={18} percentage={100} status="success" textInside />
                    <Progress strokeWidth={18} percentage={50} status="exception" textInside />
                  </div>
                )
              }
              `,
            `render() {
                return (
                  <div>
                    <Progress type="circle" percentage={0} />
                    <Progress type="circle" percentage={25} />
                    <Progress type="circle" percentage={100} status="success" />
                    <Progress type="circle" percentage={50} status="exception" />
                  </div>
                )
              }`
        ]
    },
    Pagination: {
        Code: [
            `render() {
                return (
                  <div>
                      <Pagination layout="prev, pager, next" total={50}/>
                      <Pagination layout="prev, pager, next" total={1000}/>
                  </div>
                )
              }`,
            `render() {
                return <Pagination layout="prev, pager, next" total={50} small={true}/>
              }`,
            `
              render() {
                return (
                    <div>
                      <Pagination layout="total, sizes, prev, pager, next, jumper" total={400} pageSizes={[100, 200, 300, 400]} pageSize={100} currentPage={5}/>
                    </div>
                )
              }`

        ]
    },
    Loading: {
        Code: [
            `constructor(props) {
                super(props);
              
                this.table = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 180
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 180
                    },
                    {
                      label: "地址",
                      prop: "address"
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }]
                }
              }
              
              render() {
                return (
                  <div className="ishow-loading-demo">
                    <Loading text="订单资源确认中">
                      <Table
                        style={{width: '100%'}}
                        columns={this.table.columns}
                        data={this.table.data}
                      />
                    </Loading>
                  </div>
                )
              }
              `
        ]
    },
    Message: {
        Code: [
            `open5() {
                Message({
                  showClose: true,
                  message: '恭喜你，这是一条成功消息',
                  type: 'success'
                });
              }
              
              open6() {
                Message({
                  showClose: true,
                  message: '警告哦，这是一条警告消息',
                  type: 'warning'
                });
              }
              
              open7() {
                Message({
                  showClose: true,
                  message: '这是一条消息提示',
                  type: 'info'
                });
              }
              
              open8() {
                Message({
                  showClose: true,
                  message: '错了哦，这是一条错误消息',
                  type: 'error'
                });
              }
              
              render() {
                return (
                  <div>
                    <Button plain={true} onClick={this.open5.bind(this)}>成功</Button>
                    <Button plain={true} onClick={this.open6.bind(this)}>警告</Button>
                    <Button plain={true} onClick={this.open7.bind(this)}>消息</Button>
                    <Button plain={true} onClick={this.open8.bind(this)}>错误</Button>
                  </div>
                )
              }
              `
        ]
    },
    MessageBox: {
        Code: [
            `render() {
                return <Button type="text" onClick={this.onClick.bind(this)}>点我查看消息提示</Button>
              }
              
              onClick() {
                MessageBox.alert('这是一段内容', '标题名称');
              }`,
            `render() {
                return <Button type="text" onClick={this.onClick.bind(this)}>点我确认消息</Button>
              }
              
              onClick() {
                MessageBox.confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                  type: 'warning'
                }).then(() => {
                  Message({
                    type: 'success',
                    message: '删除成功!'
                  });
                }).catch(() => {
                  Message({
                    type: 'info',
                    message: '已取消删除'
                  });
                });
              }
              `,
            `render() {
                return <Button type="text" onClick={this.onClick.bind(this)}>点我提交内容</Button>
              }
              
              onClick() {
                MessageBox.prompt('请输入邮箱', '提示', {
                  inputPattern: /[\\/w!#$%&'*+/=?^_\`{|}~-]+(?:.[w!#$%&'*+/=?^_\`{|}~-]+)*@(?:[w](?:[w-]*[w])?.)+[w](?:[w-]*[w])?\\/,
                  inputErrorMessage: '邮箱格式不正确'
                }).then(({ value }) => {
                  Message({
                    type: 'success',
                    message: '你的邮箱是: ' + value
                  });
                }).catch(() => {
                  Message({
                    type: 'info',
                    message: '取消输入'
                  });
                });
              }
              `,
            `render() {
                return <Button type="text" onClick={this.onClick.bind(this)}>点击打开 Message Box</Button>
              }
              
              onClick() {
                MessageBox.msgbox({
                  title: '消息',
                  message: '这是一段内容, 这是一段内容, 这是一段内容, 这是一段内容, 这是一段内容, 这是一段内容, 这是一段内容',
                  showCancelButton: true
                }).then(action => {
                  Message({
                    type: 'info',
                    message: 'action: ' + action
                  });
                })
              }`

        ]
    },
    Notification: {
        Code: [
            `render() {
                return (
                  <div>
                    <Button onClick={this.open3.bind(this)}>成功</Button>
                    <Button onClick={this.open4.bind(this)}>警告</Button>
                    <Button onClick={this.open5.bind(this)}>消息</Button>
                    <Button onClick={this.open6.bind(this)}>错误消息并且不会自动关闭</Button>
                  </div>
                )
              }
              
              open3() {
                Notification({
                  title: '成功',
                  message: '这是一条成功的提示消息',
                  type: 'success'
                });
              }
              
              open4() {
                Notification({
                  title: '警告',
                  message: '这是一条警告的提示消息',
                  type: 'warning'
                });
              }
              
              open5() {
                Notification.info({
                  title: '消息',
                  message: '这是一条消息的提示消息'
                });
              }
              
              open6() {
                Notification.error({
                  title: '错误',
                  message: '这是一条错误的提示消息，并且不会自动关闭',
                  duration: 0
                });
              }
              `
        ]
    },
    Menu: {
        Code: [
            `render() {
                return (
                  <div>
                    <Menu theme="dark" defaultActive="1" className="ishow-menu-demo" mode="horizontal" onSelect={this.onSelect.bind(this)}>
                      <Menu.Item index="1">处理中心</Menu.Item>
                      <Menu.SubMenu index="2" title="我的工作台">
                        <Menu.Item index="2-1">选项1</Menu.Item>
                        <Menu.Item index="2-2">选项2</Menu.Item>
                        <Menu.Item index="2-3">选项3</Menu.Item>
                      </Menu.SubMenu>
                      <Menu.Item index="3">订单管理</Menu.Item>
                    </Menu>
                    <div className="line"></div>
                    <Menu defaultActive="1" className="ishow-menu-demo" mode="horizontal" onSelect={this.onSelect.bind(this)}>
                      <Menu.Item index="1">处理中心</Menu.Item>
                      <Menu.SubMenu index="2" title="我的工作台">
                        <Menu.Item index="2-1">选项1</Menu.Item>
                        <Menu.Item index="2-2">选项2</Menu.Item>
                        <Menu.Item index="2-3">选项3</Menu.Item>
                      </Menu.SubMenu>
                      <Menu.Item index="3">订单管理</Menu.Item>
                    </Menu>
                  </div>
                )
              }
              
              onSelect() {
              
              }
              `
        ]
    },

    Tab: {
        Code: [
            `render() {
                return (
                  <Tabs activeName="2" onTabClick={ (tab) => console.log(tab.props.name) }>
                      <Tabs.Pane label="首页" name="1">首页</Tabs.Pane>
                      <Tabs.Pane label="代客注册" name="2">代客注册</Tabs.Pane>
                      <Tabs.Pane label="主推管理" name="3">主推管理</Tabs.Pane>
                      <Tabs.Pane label="任务内容管理" name="4">任务内容管理</Tabs.Pane>
                  </Tabs>
                )
              }
              `,
            `render() {
                return (
                  <Tabs type="card" value="1">
                      <Tabs.Pane label="首页" name="1">首页</Tabs.Pane>
                      <Tabs.Pane label="代客注册" name="2">代客注册</Tabs.Pane>
                      <Tabs.Pane label="主推管理" name="3">主推管理</Tabs.Pane>
                      <Tabs.Pane label="任务内容管理" name="4">任务内容管理</Tabs.Pane>
                  </Tabs>
                )
              }`,
            `render() {
                return (
                  <Tabs type="card" closable activeName="1" onTabRemove={ (tab) => console.log(tab.props.name) }>
                      <Tabs.Pane label="首页" name="1">首页</Tabs.Pane>
                      <Tabs.Pane label="代客注册" name="2">代客注册</Tabs.Pane>
                      <Tabs.Pane label="主推管理" name="3">主推管理</Tabs.Pane>
                      <Tabs.Pane label="任务内容管理" name="4">任务内容管理</Tabs.Pane>
                  </Tabs>
                )
              }`,
            `render() {
                return (
                  <Tabs type="border-card" activeName="1">
                      <Tabs.Pane label="首页" name="1">首页</Tabs.Pane>
                      <Tabs.Pane label="代客注册" name="2">代客注册</Tabs.Pane>
                      <Tabs.Pane label="主推管理" name="3">主推管理</Tabs.Pane>
                      <Tabs.Pane label="任务内容管理" name="4">任务内容管理</Tabs.Pane>
                  </Tabs>
                )
              }
              `,
            `constructor() {
                super();
                this.state = {
                  tabs: [{
                    title: 'Tab 1',
                    name: 'Tab 1',
                    content: 'Tab 1 content',
                  }, {
                    title: 'Tab 2',
                    name: 'Tab 2',
                    content: 'Tab 2 content',
                  }],
                  tabIndex: 2,
                }
              }
              
              addTab() {
                const { tabs, tabIndex } = this.state;
                const index = tabIndex + 1;
              
                tabs.push({
                  title: 'new Tab',
                  name: 'Tab ' + index,
                  content: 'new Tab content',
                });
                this.setState({
                  tabs,
                  tabIndex: index,
                });
              }
              
              removeTab(tab) {
                const { tabs, tabIndex } = this.state;
              
                tabs.splice(tab.key.replace(/^.$/, ''), 1);
                this.setState({
                  tabs,
                });
              }
              
              render() {
                return (
                  <div>
                    <div style={{marginBottom: '20px'}}>
                      <Button size="small" onClick={() => this.addTab()}>add tab</Button>
                    </div>
                    <Tabs type="card" value="Tab 2" onTabRemove={(tab) => this.removeTab(tab)}>
                      {
                        this.state.tabs.map((item, index) => {
                          return <Tabs.Pane key={index} closable label={item.title} name={item.name}>{item.content}</Tabs.Pane>
                        })
                      }
                    </Tabs>
                  </div>
                )
              }
              `
        ]
    },

    Breadcrumb: {
        Code: [
            `render() {
                return (
                  <Breadcrumb separator="/">
                    <Breadcrumb.Item>首页</Breadcrumb.Item>
                    <Breadcrumb.Item>活动管理</Breadcrumb.Item>
                    <Breadcrumb.Item>活动列表</Breadcrumb.Item>
                    <Breadcrumb.Item>活动详情</Breadcrumb.Item>
                  </Breadcrumb>
                )
              }`
        ]
    },
    Dropdown: {
        Code: [
            `render() {
                return (
                  <div>
                    <Dropdown menu={(
                      <Dropdown.Menu>
                        <Dropdown.Item>张勇</Dropdown.Item>
                        <Dropdown.Item>陈瑜婷</Dropdown.Item>
                        <Dropdown.Item>盛瑜</Dropdown.Item>
                        <Dropdown.Item>刘兴</Dropdown.Item>
                        <Dropdown.Item>赵斐昊</Dropdown.Item>
                        <Dropdown.Item>黄杰</Dropdown.Item>
                        <Dropdown.Item>刘泽琼</Dropdown.Item>
                        <Dropdown.Item>唐媛媛</Dropdown.Item>
                      </Dropdown.Menu>
                    )}>
                      <Button type="primary">
                       途牛ELF-Team成员<i className="ishow-icon-caret-bottom ishow-icon--right"></i>
                      </Button>
                    </Dropdown>
                  </div>
                )
              }
              `
        ]
    },
    Steps: {
        Code: [
            `render() {
                return (
                  <Steps space={100} active={1} finishStatus="success">
                    <Steps.Step title="已完成"></Steps.Step>
                    <Steps.Step title="进行中"></Steps.Step>
                    <Steps.Step title="步骤 3"></Steps.Step>
                  </Steps>
                )
              }
              `,
            `render() {
                return (
                  <Steps space={200} active={1}>
                    <Steps.Step title="步骤 1" description="这是一段很长很长很长的描述性文字"></Steps.Step>
                    <Steps.Step title="步骤 2" description="这是一段很长很长很长的描述性文字"></Steps.Step>
                    <Steps.Step title="步骤 3" description="这是一段很长很长很长的描述性文字"></Steps.Step>
                  </Steps>
                )
              }`,
            `render() {
                return (
                  <Steps space={100} active={1}>
                    <Steps.Step title="步骤 1" icon="edit"></Steps.Step>
                    <Steps.Step title="步骤 2" icon="upload"></Steps.Step>
                    <Steps.Step title="步骤 3" icon="picture"></Steps.Step>
                  </Steps>
                )
              }`,
            `constructor(props) {
                super(props);
              
                this.state = {
                  active: 0
                };
              }
              
              next() {
                let active = this.state.active + 1;
                if (active > 3) {
                  active = 0;
                }
                this.setState({ active });
              }
              
              render() {
                return (
                  <div>
                    <Steps space={200} active={this.state.active} finishStatus="success">
                      <Steps.Step title="步骤 1"></Steps.Step>
                      <Steps.Step title="步骤 2"></Steps.Step>
                      <Steps.Step title="步骤 3"></Steps.Step>
                    </Steps>
                    <Button onClick={() => this.next()}>下一步</Button>
                  </div>
                )
              }
              `
        ]
    },
    Dialog: {
        Code: [
            `constructor(props) {
                super(props);
              
                this.state = {
                  dialogVisible: false
                };
              }
              
              render() {
                return (
                  <div>
                    <Button type="text" onClick={ () => this.setState({ dialogVisible: true }) }>点击打开 Dialog</Button>
                    <Dialog
                      title="提示"
                      size="tiny"
                      visible={ this.state.dialogVisible }
                      onCancel={ () => this.setState({ dialogVisible: false }) }
                      lockScroll={ false }
                    >
                      <Dialog.Body>
                        <span>这是一段信息</span>
                      </Dialog.Body>
                      <Dialog.Footer className="dialog-footer">
                        <Button onClick={ () => this.setState({ dialogVisible: false }) }>取消</Button>
                        <Button type="primary" onClick={ () => this.setState({ dialogVisible: false }) }>确定</Button>
                      </Dialog.Footer>
                    </Dialog>
                  </div>
                )
              }
              `,
            `constructor(props) {
                super(props);
              
                this.state = {
                  dialogVisible2: false,
                  dialogVisible3: false,
                  form: {
                    name: '',
                    region: ''
                  }
                };
              
                this.table = {
                  columns: [
                    {
                      label: "日期",
                      prop: "date",
                      width: 150
                    },
                    {
                      label: "姓名",
                      prop: "name",
                      width: 100
                    },
                    {
                      label: "地址",
                      prop: "address"
                    }
                  ],
                  data: [{
                    date: '2018-03-02',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-04',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-01',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }, {
                    date: '2018-03-03',
                    name: '途牛大前端 -- 张勇',
                    address: '南京市玄武区玄武大道699-32号途牛大厦'
                  }]
                };
              }
              
              render() {
                return (
                  <div>
                    <Button type="text" onClick={ () => this.setState({ dialogVisible2: true }) } type="text">打开嵌套表格的 Dialog</Button>
                    <Dialog
                      title="收货地址"
                      visible={ this.state.dialogVisible2 }
                      onCancel={ () => this.setState({ dialogVisible2: false }) }
                    >
                      <Dialog.Body>
                        {this.state.dialogVisible2 && (
                          <Table
                           style={{width: '100%'}}
                           stripe={true}
                           columns={this.table.columns}
                           data={this.table.data} />
                        )}
                      </Dialog.Body>
                    </Dialog>
                    <Button type="text" onClick={ () => this.setState({ dialogVisible3: true }) } type="text">打开嵌套表单的 Dialog</Button>
                    <Dialog
                      title="收货地址"
                      visible={ this.state.dialogVisible3 }
                      onCancel={ () => this.setState({ dialogVisible3: false }) }
                    >
                      <Dialog.Body>
                        <Form model={this.state.form}>
                          <Form.Item label="活动名称" labelWidth="120">
                            <Input value={this.state.form.name}></Input>
                          </Form.Item>
                          <Form.Item label="活动区域" labelWidth="120">
                            <Select value={this.state.form.region} placeholder="请选择活动区域">
                              <Select.Option label="区域一" value="shanghai"></Select.Option>
                              <Select.Option label="区域二" value="beijing"></Select.Option>
                            </Select>
                          </Form.Item>
                        </Form>
                      </Dialog.Body>
              
                      <Dialog.Footer className="dialog-footer">
                        <Button onClick={ () => this.setState({ dialogVisible3: false }) }>取 消</Button>
                        <Button type="primary" onClick={ () => this.setState({ dialogVisible3: false }) }>确 定</Button>
                      </Dialog.Footer>
                    </Dialog>
                  </div>
                )
              }
              `
        ]
    },
    BarChart:{
      Code:[
        `
        import React from 'react'
        import ReactEcharts from 'echarts-for-react'

        class App extends React.Component {
            getOption = () => {
                return {
                    xAxis: {
                        type: 'category',
                        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        data: [120, 100, 150, 80, 70, 110, 130, 80, 70, 110, 130, 120],
                        type: 'bar',
                        color: "#2da0ff"
                    }]
                };
            };

            render() {
                return (
                    <ReactEcharts
                        option={this.getOption()}
                        style={{ height: '300px', width: '65%' }}
                        className='react_for_echarts' />
                )
            }
        }

        export default App
        `,
      ]
    },
    PieChart:{
      Code:[
        ` import React from 'react'
          import ReactEcharts from 'echarts-for-react'

          class App extends React.Component {
              getOption = () => {
                  return {
                      title: {
                          show: true
                      },
                      tooltip: {
                          trigger: 'item',
                          formatter: "{a} <br/>{b}: {c} ({d}%)"
                      },
                      legend: {
                          orient: 'vertical',
                          right: 0,
                          top: 100,
                          data: ['跟团游', '自由行', '邮轮', '机票', '酒店', "火车票"]
                      },
                      series: [
                          {
                              name: '访问来源',
                              hoverAnimation: false,
                              type: 'pie',
                              radius: ['50%', '70%'],
                              avoidLabelOverlap: false,
                              label: {
                                  normal: {
                                      show: false,
                                      position: 'center'
                                  },
                                  emphasis: {
                                      show: true,
                                      textStyle: {
                                          fontSize: '30',
                                          fontWeight: 'bold'
                                      }
                                  }
                              },
                              labelLine: {
                                  normal: {
                                      show: false
                                  }
                              },
                              data: [
                                  { value: 335, name: '跟团游' },
                                  { value: 310, name: '自由行' },
                                  { value: 234, name: '邮轮' },
                                  { value: 135, name: '机票' },
                                  { value: 1548, name: '酒店' },
                                  { value: 1324, name: '火车票' }
                              ]
                          }
                      ]
                  };
              };

              render() {
                  return (
                      <ReactEcharts
                        option={this.getOption()}
                        style={{ height: '300px', width: '500px' }}
                        className='react_for_echarts' />
                  )
              }
          }

          export default App`
      ]
    },
    LineChart:{
      Code:[
        `
        import React from 'react'
        import ReactEcharts from 'echarts-for-react'
        import ViewCode from './viewCode'
        import ParamTable from './paramTable'
        import { Tabs } from 'element-react'

        class App extends React.Component {
            getOption = () => {
                return {
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: ['客流量', '支付笔数']
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    dataZoom: {
                        type: 'slider',
                        show: true,
                        xAxisIndex: [0],
                        start: 0,
                        end: 100,
                        bottom: "0px"
                    },
                    series: [
                        {
                            name: '支付笔数',
                            type: 'line',
                            stack: '总量',
                            data: [120, 132, 101, 134, 90, 230, 210, 132, 101, 134, 90, 230, 210, 132, 101, 134, 90, 230, 210, 190, 132, 101, 120, 132, 123]
                        },
                        {
                            name: '客流量',
                            type: 'line',
                            stack: '总量',
                            data: [220, 182, 191, 234, 290, 330, 310, 220, 182, 191, 234, 290, 330, 310, 220, 182, 191, 234, 290, 300, 310, 123, 232, 231]
                        }
                    ]
                };
            };

            render() {
                return (
                    <ReactEcharts
                      option={this.getOption()}
                      style={{ height: '300px', width: '1000px' }}
                      className='react_for_echarts' />
                )
            }
        }

        export default App
        `
      ]
    }
}