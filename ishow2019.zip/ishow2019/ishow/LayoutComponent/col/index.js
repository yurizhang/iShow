

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _grid = require('../grid');
require('./style/css');
exports['default'] = _grid.Col;
module.exports = exports['default'];