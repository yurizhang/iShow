import Carousel from './Carousel.js';
import CarouselItem from './CarouselItem.js';

Carousel.Item = CarouselItem;

export default Carousel;