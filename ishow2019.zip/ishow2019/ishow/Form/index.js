import Form from './Form.js';
import FormItem from './FormItem.js';

Form.Item = FormItem;

export default Form;
