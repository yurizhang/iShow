import Steps from './Steps';
import Step from './Step';

Steps.Step = Step;

export default Steps;
